﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace JPWeatherproofSystem
{
    public partial class GearDetails : Form
    {
        public GearDetails()
        {
            InitializeComponent();
        }

        private void GearDetails_Load(object sender, EventArgs e)
        {
            string sql = "Select * from Gear";
            DBHelper.fill(sql, dataGridView1);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string sql = "Insert into Gear(gear_name,quantity,sizes,availability)values('" + textBox1.Text + "'," +Convert.ToInt32(textBox3.Text) + ",'"+ textBox2.Text+ "','"+ textBox5.Text+ "')";
                DBHelper.fill(sql, dataGridView1);
                GearDetails_Load(sender, e);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            textBox4.Text = dataGridView1[0, e.RowIndex].Value.ToString();
            textBox1.Text = dataGridView1[1, e.RowIndex].Value.ToString();
            textBox3.Text = dataGridView1[2, e.RowIndex].Value.ToString();
            textBox2.Text = dataGridView1[3, e.RowIndex].Value.ToString();
            textBox5.Text = dataGridView1[4, e.RowIndex].Value.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                string sql = "Update Gear SET gear_name      ='" + textBox1.Text +
                 "',quantity      = " +Convert.ToInt32(textBox3.Text) +
           ",sizes         =  '" + textBox2.Text +
           "',availability = '"+textBox5.Text+
                 "' where gear_ID = " + Convert.ToInt32(textBox4.Text) + "";
                DBHelper.ModifyRecord(sql);
                MessageBox.Show("Data has been updated...", "Update stock", MessageBoxButtons.OK, MessageBoxIcon.Information);
                GearDetails_Load(sender, e);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            string sql = "delete * from Gear where gear_ID = " + Convert.ToInt32(textBox4.Text) + "";
            DBHelper.ModifyRecord(sql);
            MessageBox.Show("Data has been Delete...", "Update stock",
MessageBoxButtons.OK, MessageBoxIcon.Information);
            GearDetails_Load(sender, e);
        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {
            try
            {

                string srh = textBox8.Text.Trim();
                if (srh != "")
                {
                    string sql = "SELECT * from Gear where gear_name like '" + srh + "%'"
                        + "OR availability like '" + srh + "%'";
                    // string data = "select * from Product where RagColor like '" + txtsearch.Text + "%'";


                    DBHelper.fill(sql, dataGridView1);

                }
                else
                {
                    GearDetails_Load(sender, e);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
    }

