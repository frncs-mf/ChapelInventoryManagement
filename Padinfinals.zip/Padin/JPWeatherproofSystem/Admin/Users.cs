﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JPWeatherproofSystem
{
    public partial class Users : Form
    {
        public Users()
        {
            InitializeComponent();
        }

       

        private void Users_Load(object sender, EventArgs e)
        {
            string sql = "Select * from Account";
            DBHelper.fill(sql,dataGridView1);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                string sql = "Insert into Account(Firstname,Lastname,Email)values('"+ textBox2.Text+ "','"+ textBox3.Text + "','"+ textBox4.Text+ "')";
                DBHelper.fill(sql, dataGridView1);
                Users_Load( sender,  e);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                string sql = "Update Account SET Firstname      ='" + textBox2.Text +
                 "',Lastname      = '" + textBox3.Text +
           "',Email         =  '" + textBox4.Text +
                 "' where account_ID = " + Convert.ToInt32(textBox1.Text) + "";
                DBHelper.ModifyRecord(sql);
                MessageBox.Show("Data has been updated...", "Update stock",MessageBoxButtons.OK, MessageBoxIcon.Information);
                Users_Load(sender, e);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            textBox1.Text = dataGridView1[0, e.RowIndex].Value.ToString();
            textBox2.Text = dataGridView1[1, e.RowIndex].Value.ToString();
            textBox3.Text = dataGridView1[2, e.RowIndex].Value.ToString();
            textBox4.Text = dataGridView1[3, e.RowIndex].Value.ToString();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string sql = "delete * from Account where account_ID = " + Convert.ToInt32(textBox1.Text) + "";
            DBHelper.ModifyRecord(sql);
            MessageBox.Show("Data has been Delete...", "Update stock",
MessageBoxButtons.OK, MessageBoxIcon.Information);
            Users_Load(sender, e);

        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {
            try
            {

                string srh = textBox8.Text.Trim();
                if (srh != "")
                {
                    string sql = "SELECT * from Account where Firstname like '" + srh + "%'"
                        + "OR Lastname like '" + srh + "%'";
                    // string data = "select * from Product where RagColor like '" + txtsearch.Text + "%'";


                    DBHelper.fill(sql, dataGridView1);

                }
                else
                {
                    Users_Load(sender, e);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
