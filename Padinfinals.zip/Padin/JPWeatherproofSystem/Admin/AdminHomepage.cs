﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JPWeatherproofSystem
{
    public partial class AdminHomepage : Form
    {
        public AdminHomepage()
        {
            InitializeComponent();
        }

        private void usersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Users s= new Users();
            s.Show();
        }

        private void gearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GearDetails s= new GearDetails();
            s.Show();
        }

        private void borrowersToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void crystalReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            report s = new report();
            s.Show();
        }
    }
}
