﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JPWeatherproofSystem
{

    public partial class Gear : Form
    {
        int raincoatquan = 0;
        int boatsquan = 0;
        int payongquan = 0;
        string chooseitem = "";

        public Gear()
        {
            InitializeComponent();
            textBox1.Enabled = false;
            textBox2.Enabled = false;
            textBox3.Enabled = false;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            raincoatquan++;
            textBox1.Text = raincoatquan.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            raincoatquan--;
            textBox1.Text = raincoatquan.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            payongquan++;
            textBox2.Text = payongquan.ToString();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            payongquan--;
            textBox2.Text = payongquan.ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            boatsquan++;
            textBox3.Text = boatsquan.ToString();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            boatsquan--;
            textBox3.Text = boatsquan.ToString();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            int total = raincoatquan + payongquan + boatsquan;
            string sql = "insert into Borrowers (BurrowItem,Quantities,Sizes)values('"+chooseitem+"',"+ total + ",'"+ comboBox1.Text+ "')";
            DBHelper.ModifyRecord(sql);
            MessageBox.Show("Successfuly Borrowed");
        }

        private void button8_Click(object sender, EventArgs e)
        {
            chooseitem = "raincoat";
            //payong
            button9.Enabled = false;
            button3.Enabled = false;
            button5.Enabled = false;
            //boats
            button10.Enabled = false;
            button4.Enabled = false;
            button6.Enabled = false;

        }

        private void button9_Click(object sender, EventArgs e)
        {
            chooseitem = "payong";
            //raincoat
            button8.Enabled = false;
            button1.Enabled = false;
            button2.Enabled = false;
            //boats
            button10.Enabled = false;
            button4.Enabled = false;
            button6.Enabled = false;

        }

        private void button10_Click(object sender, EventArgs e)
        {
            chooseitem = "boots";
            //raincoat

            button8.Enabled = false;
            button1.Enabled = false;
            button2.Enabled = false;
            //payong
            button9.Enabled = false;
            button3.Enabled = false;
            button5.Enabled = false;
        }
    }
}
