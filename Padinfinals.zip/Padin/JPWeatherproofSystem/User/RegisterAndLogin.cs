﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace JPWeatherproofSystem
{
    public partial class RegisterAndLogin : Form
    {
        public RegisterAndLogin()
        {
            InitializeComponent();
            txtpassword.UseSystemPasswordChar = true;
            textBox7.UseSystemPasswordChar = true;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            string str = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\\Users\\niiin\\OneDrive\\Pictures\\Padin\\JPWeatherproofSystem\\bin\\Debug\\JPDatabase.accdb";
            OleDbConnection conn = new OleDbConnection(str);          
            conn.Open();
            OleDbCommand command = new OleDbCommand("INSERT INTO Account (Firstname,Lastname,Email,Privacy) Values " + "(@Firstname,@Lastname,@Email,@Privacy)", conn);
            command.Parameters.AddWithValue("@Firstname", txtfirstname.Text);
            command.Parameters.AddWithValue("@Lastname", txtlastname.Text);
            command.Parameters.AddWithValue("@Email", txtemail.Text);
            command.Parameters.AddWithValue("@Privacy", txtpassword.Text);
            MessageBox.Show("Successfully Registered");
            command.ExecuteNonQuery();
            conn.Close();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                txtpassword.UseSystemPasswordChar = false;
            }
            else
            {
                txtpassword.UseSystemPasswordChar = true;
            }
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                textBox7.UseSystemPasswordChar = true;
            }
            else
            {
                textBox7.UseSystemPasswordChar = false;

            }
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            panel1.Visible = true;

            panel2.Visible = false;
        }

        private void linkLabel3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            panel1.Visible = false;

            panel2.Visible = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string str = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\\Users\\niiin\\OneDrive\\Pictures\\Padin\\JPWeatherproofSystem\\bin\\Debug\\JPDatabase.accdb";
            OleDbConnection conn = new OleDbConnection(str);
            conn.Open();
            OleDbCommand command = new OleDbCommand("Select count(*) from Account where Email=@Email AND Privacy=@Privacy ", conn);
            command.Parameters.AddWithValue("@Email", textBox6.Text);
            command.Parameters.AddWithValue("@Privacy", textBox7.Text);
            command.ExecuteNonQuery();
            int count = (int)command.ExecuteScalar();
            conn.Close();
            if (count > 0)
            {
                MessageBox.Show("Welcome");
                UsersHomepage s= new UsersHomepage();
                s.Show();
            }
            else if (textBox6.Text == "admin")
            {
                if (textBox7.Text == "admin")
                {
                    AdminHomepage s = new AdminHomepage();
                    s.Show();
                    MessageBox.Show("Welcome");

                }
                else
                {
                    MessageBox.Show("Invalid");

                }
            }
            else
            {
                MessageBox.Show("Invalid");
            }
        }
    }
}
