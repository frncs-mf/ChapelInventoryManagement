﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JPWeatherproofSystem
{
    internal class GlobalDeclaration
    {
        public static OleDbCommand command;
        public static OleDbDataReader reader;
        public static int itemcode;
        public static int ORNO;
    }
}
