﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JPWeatherproofSystem
{
    internal class Connection
    {
        //for connection string
        public static OleDbConnection conn;
        private static string dbconnect = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\\Users\\niiin\\OneDrive\\Pictures\\Padin\\JPWeatherproofSystem\\bin\\Debug\\JPDatabase.accdb";


        public static void DB()
        {
            try
            {
                conn = new OleDbConnection(dbconnect);
                conn.Open();
            }


            catch (Exception ex)
            {
                conn.Close();
                MessageBox.Show(ex.Message);

            }
        }
    }
}
