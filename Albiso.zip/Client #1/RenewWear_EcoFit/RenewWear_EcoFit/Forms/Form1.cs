﻿using Guna.UI2.AnimatorNS;
using Guna.UI2.WinForms;
using RenewWear_EcoFit.Forms;
using RenewWear_EcoFit.UserDataAccess;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RenewWear_EcoFit
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            pictureBox1.Parent = pnlLoginBackground;
            txtContact.KeyPress += TxtContact_KeyPress;
            txtIDnumber.KeyPress += TxtIDnumber_KeyPress;
            txtPassword.UseSystemPasswordChar = true;


        }

        private void TxtContact_KeyPress(object sender, KeyPressEventArgs e)
        {
            bool isDigit = char.IsDigit(e.KeyChar);

            if (!isDigit && e.KeyChar != '\b')
            {
                e.Handled = true;
            }

        }

        private void TxtIDnumber_KeyPress(object sender, KeyPressEventArgs e)
        {
            bool isDigit = char.IsDigit(e.KeyChar);

            if (!isDigit && e.KeyChar != '\b')
            {
                e.Handled = true;
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }


        private void btnLogin_Click(object sender, EventArgs e)
        {

            if (txtUsername.Text == "admin" && txtPassword.Text == "admin")
            {
                AdminForm adminform = new AdminForm();
                adminform.Show();
                return;
            }

            pnlSlideTransition.AnimationType = AnimationType.VertSlide;
            pnlSlideTransition.HideSync(pnlSignUp, true, Animation.VertSlide);

            if (string.IsNullOrEmpty(txtUsername.Text))
            {
                txtUsername.BorderColor = Color.Red;
                //errorUsername.Visible = true;
            }

            if (string.IsNullOrEmpty(txtPassword.Text))
            {
                txtPassword.BorderColor = Color.Red;
                //errorPassword.Visible = true;
            }

            if (string.IsNullOrEmpty(txtPassword.Text) || string.IsNullOrEmpty(txtUsername.Text))
            {
                MessageBox.Show("Some fields are not filled up. Please complete all required fields before proceeding.", "Incomplete Form", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            string username = txtUsername.Text;
            string password = txtPassword.Text;

            try
            {
                bool isAuthenticated = DataAccess.AuthenticateUser(username, password);
                if (isAuthenticated)
                {
                    int userID = DataAccess.RetrieveUserID(username);
                    //this.Hide();
                    UserForm userform = new UserForm(userID);
                    userform.Show();
                   

                }
                else
                {
                    MessageBox.Show("Invalid username or password. Please try again.", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while trying to log in: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void btnSignUp_Click(object sender, EventArgs e)
        {

            pnlSlideTransition.AnimationType = AnimationType.VertSlide;
            pnlSlideTransition.ShowSync(pnlSignUp, true, Animation.VertSlide);

        }

        private void pnlSignUp_Paint(object sender, PaintEventArgs e)
        {

        }

        private void guna2TextBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private async void btnRegister_Click(object sender, EventArgs e)
        {
            Form1 form1 = this;

            if (string.IsNullOrEmpty(txtFirstname.Text))
            {
                txtFirstname.BorderColor = Color.Red;
                //errorFirstname.Visible = true;
            }
            if (string.IsNullOrEmpty(txtLastname.Text))
            {
                txtLastname.BorderColor = Color.Red;
                //errorLastname.Visible = true;
            }
            if (string.IsNullOrEmpty(txtIDnumber.Text))
            {
                txtIDnumber.BorderColor = Color.Red;
                //errorIDnumber.Visible = true;
            }
            if (string.IsNullOrEmpty(txtContact.Text))
            {
                txtContact.BorderColor = Color.Red;
                //errorContact.Visible = true;
            }
            if (string.IsNullOrEmpty(txtNewPassword.Text))
            {
                txtNewPassword.BorderColor = Color.Red;
                //errorNewPassword.Visible = true;
            }
            if (string.IsNullOrEmpty(txtConfirmPassword.Text))
            {
                txtConfirmPassword.BorderColor = Color.Red;
                //errorConfirmPassword.Visible = true;
            }
            if (txtConfirmPassword.Text != txtNewPassword.Text)
            {
                txtConfirmPassword.BorderColor = Color.Red;
                //errorConfirmPassword.Visible = true;
                txtConfirmPassword.BorderColor = Color.Red;
                //errorConfirmPassword.Visible = true;

                MessageBox.Show("The password and re-entered password do not match. Please ensure that both passwords are identical.", "Password Mismatch", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (string.IsNullOrEmpty(txtFirstname.Text) ||
                string.IsNullOrEmpty(txtLastname.Text) ||
                string.IsNullOrEmpty(txtIDnumber.Text) ||
                string.IsNullOrEmpty(txtContact.Text) ||
                string.IsNullOrEmpty(txtNewPassword.Text) ||
                string.IsNullOrEmpty(txtConfirmPassword.Text) ||
                (txtConfirmPassword.Text != txtNewPassword.Text))
            {
                MessageBox.Show("Some fields are not filled up. Please complete all required fields before proceeding.", "Incomplete Form", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            DialogResult result = MessageBox.Show("Are you sure you want to register?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                pnlLoadingRegister.Visible = true;
                await Task.Delay(3000);

                string firstName = txtFirstname.Text;
                string lastName = txtLastname.Text;
                int IDnumber = Convert.ToInt32(txtIDnumber.Text);
                int contact = Convert.ToInt32(txtContact.Text);
                string password = txtConfirmPassword.Text;
                string gender = rbtnMale.Checked ? "Male" : "Female";

                try
                {
                    bool registrationResult = DataAccess.RegisterUser(firstName, lastName, IDnumber, contact, password, gender);
                    pnlLoadingRegister.Visible = false;

                    if (registrationResult)
                    {

                        _ = Task.Run(() =>
                        {
                            MessageBox.Show("Registration successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }).ContinueWith(task =>
                        {
                            if (task.Status == TaskStatus.RanToCompletion)
                            {
                                pnlSlideTransition.AnimationType = AnimationType.VertSlide;
                                pnlSlideTransition.HideSync(pnlSignUp, true, Animation.VertSlide);
                            }
                        }, TaskScheduler.FromCurrentSynchronizationContext());
                    }
                    else
                    {
                        MessageBox.Show("This email address is already registered. Please use a different one.", "Registration Failed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred while registering: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
            else
            {
                return;
            }
        }


        private void txtUsername_TextChanged(object sender, EventArgs e)
        {
            if (txtUsername.Text != null)
            {
                txtUsername.BorderColor = Color.FromArgb(41, 171, 223);
            }
        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {
            if (txtPassword.Text != null)
            {
                txtPassword.BorderColor = Color.FromArgb(41, 171, 223);
            }
        }

        private void txtFirstname_TextChanged(object sender, EventArgs e)
        {
            if (txtFirstname.Text != null)
            {
                txtFirstname.BorderColor = Color.FromArgb(41, 171, 223);
            }
        }

        private void txtLastname_TextChanged(object sender, EventArgs e)
        {
            if (txtLastname.Text != null)
            {
                txtLastname.BorderColor = Color.FromArgb(41, 171, 223);
            }
        }

        private void pnlLoginBackground_Click(object sender, EventArgs e)
        {

        }
    }
}
