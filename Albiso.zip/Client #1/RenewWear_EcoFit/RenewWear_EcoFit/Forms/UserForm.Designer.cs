﻿namespace RenewWear_EcoFit.Forms
{
    partial class UserForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UserForm));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            this.guna2GradientPanel1 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.guna2CirclePictureBox1 = new Guna.UI2.WinForms.Guna2CirclePictureBox();
            this.guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2GradientPanel2 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.guna2Panel5 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel6 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            this.btnSignUp = new Guna.UI2.WinForms.Guna2GradientTileButton();
            this.sidenavbar = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.btnAboutUsPanel = new Guna.UI2.WinForms.Guna2GradientButton();
            this.btnEditProfilePanel = new Guna.UI2.WinForms.Guna2GradientButton();
            this.btnStatusPanel = new Guna.UI2.WinForms.Guna2GradientButton();
            this.btnDropOff = new Guna.UI2.WinForms.Guna2GradientButton();
            this.btnProfilename = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2GradientPanel4 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.pbProfile = new Guna.UI2.WinForms.Guna2PictureBox();
            this.RequestPanel = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.guna2HtmlLabel8 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel7 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel6 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.btnSpecial = new Guna.UI2.WinForms.Guna2ImageButton();
            this.btnDryClean = new Guna.UI2.WinForms.Guna2ImageButton();
            this.btnStandard = new Guna.UI2.WinForms.Guna2ImageButton();
            this.guna2GradientPanel5 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.SpecialtyCleaningPanel = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            this.guna2GradientPanel9 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.txtSpecialtyTotalPrice = new System.Windows.Forms.RichTextBox();
            this.btnSpecialtyAddTransaction = new Guna.UI2.WinForms.Guna2GradientButton();
            this.numUpSpecialLoad = new Guna.UI2.WinForms.Guna2NumericUpDown();
            this.guna2HtmlLabel15 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.checkBoxSpecialStainRemove = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.guna2HtmlLabel16 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.checkBoxSpecialFabSoft = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.guna2HtmlLabel17 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.checkBoxSpecialHand = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.guna2HtmlLabel18 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.checkBoxSpecialEco = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.guna2HtmlLabel19 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.checkBoxSpecialAntiBac = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.guna2HtmlLabel20 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.StandardPanel = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            this.guna2GradientPanel6 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.txtStandardTotal = new System.Windows.Forms.RichTextBox();
            this.btnStandardAddTransaction = new Guna.UI2.WinForms.Guna2GradientButton();
            this.numUpLoad = new Guna.UI2.WinForms.Guna2NumericUpDown();
            this.guna2HtmlLabel10 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.checkBoxGentWash = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.oy = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.checkBoxFabSoft = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.guna2HtmlLabel5 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.checkBoxScent = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.oi = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.checkBoxIron = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.guna2HtmlLabel3 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.checkBoxAntiBac = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.guna2HtmlLabel2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.DryCleaningPanel = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            this.guna2GradientPanel8 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.txtDryTotalPrice = new System.Windows.Forms.RichTextBox();
            this.btnDryAddTransaction = new Guna.UI2.WinForms.Guna2GradientButton();
            this.numUpDryLoad = new Guna.UI2.WinForms.Guna2NumericUpDown();
            this.guna2HtmlLabel4 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.checkBoxDelCare = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.guna2HtmlLabel9 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.checkBoxDryFabSoft = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.guna2HtmlLabel11 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.checkBoxDryMinorRepair = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.guna2HtmlLabel12 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.checkBoxDryPress = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.guna2HtmlLabel13 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.checkBoxDryAntiBac = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.guna2HtmlLabel14 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.StatusPanel = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.guna2Panel2 = new Guna.UI2.WinForms.Guna2Panel();
            this.cancelTransaction = new Guna.UI2.WinForms.Guna2GradientButton();
            this.refresh = new Guna.UI2.WinForms.Guna2GradientButton();
            this.TransactionStatusDataGridView = new Guna.UI2.WinForms.Guna2DataGridView();
            this.TrackNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IDNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Type = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DateTimeSchedule = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Status = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TotalPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PanelInfo = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.lblGender = new System.Windows.Forms.Label();
            this.lblContact = new System.Windows.Forms.Label();
            this.lblID = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.guna2GradientPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox1)).BeginInit();
            this.guna2GradientPanel2.SuspendLayout();
            this.guna2Panel5.SuspendLayout();
            this.guna2Panel1.SuspendLayout();
            this.sidenavbar.SuspendLayout();
            this.guna2GradientPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbProfile)).BeginInit();
            this.RequestPanel.SuspendLayout();
            this.guna2GradientPanel5.SuspendLayout();
            this.SpecialtyCleaningPanel.SuspendLayout();
            this.guna2GradientPanel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numUpSpecialLoad)).BeginInit();
            this.StandardPanel.SuspendLayout();
            this.guna2GradientPanel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numUpLoad)).BeginInit();
            this.DryCleaningPanel.SuspendLayout();
            this.guna2GradientPanel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDryLoad)).BeginInit();
            this.StatusPanel.SuspendLayout();
            this.guna2Panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TransactionStatusDataGridView)).BeginInit();
            this.PanelInfo.SuspendLayout();
            this.SuspendLayout();
            // 
            // guna2GradientPanel1
            // 
            this.guna2GradientPanel1.Controls.Add(this.guna2CirclePictureBox1);
            this.guna2GradientPanel1.Controls.Add(this.guna2HtmlLabel1);
            this.guna2GradientPanel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.guna2GradientPanel1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(107)))), ((int)(((byte)(139)))));
            this.guna2GradientPanel1.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.guna2GradientPanel1.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.guna2GradientPanel1.Location = new System.Drawing.Point(0, 0);
            this.guna2GradientPanel1.Name = "guna2GradientPanel1";
            this.guna2GradientPanel1.Size = new System.Drawing.Size(1021, 89);
            this.guna2GradientPanel1.TabIndex = 3;
            // 
            // guna2CirclePictureBox1
            // 
            this.guna2CirclePictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.guna2CirclePictureBox1.FillColor = System.Drawing.Color.Transparent;
            this.guna2CirclePictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("guna2CirclePictureBox1.Image")));
            this.guna2CirclePictureBox1.ImageRotate = 0F;
            this.guna2CirclePictureBox1.Location = new System.Drawing.Point(39, 12);
            this.guna2CirclePictureBox1.Name = "guna2CirclePictureBox1";
            this.guna2CirclePictureBox1.ShadowDecoration.Color = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.guna2CirclePictureBox1.ShadowDecoration.Enabled = true;
            this.guna2CirclePictureBox1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CirclePictureBox1.ShadowDecoration.Shadow = new System.Windows.Forms.Padding(10);
            this.guna2CirclePictureBox1.Size = new System.Drawing.Size(76, 67);
            this.guna2CirclePictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2CirclePictureBox1.TabIndex = 3;
            this.guna2CirclePictureBox1.TabStop = false;
            // 
            // guna2HtmlLabel1
            // 
            this.guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel1.Font = new System.Drawing.Font("Cooper Black", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel1.ForeColor = System.Drawing.Color.White;
            this.guna2HtmlLabel1.Location = new System.Drawing.Point(377, 22);
            this.guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            this.guna2HtmlLabel1.Size = new System.Drawing.Size(343, 42);
            this.guna2HtmlLabel1.TabIndex = 1;
            this.guna2HtmlLabel1.Text = "RenewWear EcoFit";
            // 
            // guna2GradientPanel2
            // 
            this.guna2GradientPanel2.Controls.Add(this.guna2Panel5);
            this.guna2GradientPanel2.Controls.Add(this.guna2Panel1);
            this.guna2GradientPanel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.guna2GradientPanel2.FillColor = System.Drawing.Color.WhiteSmoke;
            this.guna2GradientPanel2.FillColor2 = System.Drawing.Color.Silver;
            this.guna2GradientPanel2.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.guna2GradientPanel2.Location = new System.Drawing.Point(0, 89);
            this.guna2GradientPanel2.Name = "guna2GradientPanel2";
            this.guna2GradientPanel2.Size = new System.Drawing.Size(1021, 40);
            this.guna2GradientPanel2.TabIndex = 5;
            // 
            // guna2Panel5
            // 
            this.guna2Panel5.Controls.Add(this.guna2Panel6);
            this.guna2Panel5.Location = new System.Drawing.Point(682, 40);
            this.guna2Panel5.Name = "guna2Panel5";
            this.guna2Panel5.Size = new System.Drawing.Size(267, 257);
            this.guna2Panel5.TabIndex = 7;
            // 
            // guna2Panel6
            // 
            this.guna2Panel6.Location = new System.Drawing.Point(269, 0);
            this.guna2Panel6.Name = "guna2Panel6";
            this.guna2Panel6.Size = new System.Drawing.Size(267, 257);
            this.guna2Panel6.TabIndex = 6;
            // 
            // guna2Panel1
            // 
            this.guna2Panel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2Panel1.Controls.Add(this.btnSignUp);
            this.guna2Panel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.guna2Panel1.Location = new System.Drawing.Point(934, 0);
            this.guna2Panel1.Name = "guna2Panel1";
            this.guna2Panel1.Size = new System.Drawing.Size(87, 40);
            this.guna2Panel1.TabIndex = 5;
            // 
            // btnSignUp
            // 
            this.btnSignUp.BackColor = System.Drawing.Color.Transparent;
            this.btnSignUp.BorderRadius = 5;
            this.btnSignUp.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnSignUp.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnSignUp.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnSignUp.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnSignUp.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnSignUp.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnSignUp.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnSignUp.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnSignUp.ForeColor = System.Drawing.Color.White;
            this.btnSignUp.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.btnSignUp.Location = new System.Drawing.Point(3, 6);
            this.btnSignUp.Name = "btnSignUp";
            this.btnSignUp.Size = new System.Drawing.Size(79, 31);
            this.btnSignUp.TabIndex = 4;
            this.btnSignUp.Text = "Log Out";
            // 
            // sidenavbar
            // 
            this.sidenavbar.Controls.Add(this.btnAboutUsPanel);
            this.sidenavbar.Controls.Add(this.btnEditProfilePanel);
            this.sidenavbar.Controls.Add(this.btnStatusPanel);
            this.sidenavbar.Controls.Add(this.btnDropOff);
            this.sidenavbar.Controls.Add(this.btnProfilename);
            this.sidenavbar.Controls.Add(this.guna2GradientPanel4);
            this.sidenavbar.Dock = System.Windows.Forms.DockStyle.Left;
            this.sidenavbar.FillColor = System.Drawing.Color.PowderBlue;
            this.sidenavbar.FillColor2 = System.Drawing.Color.CadetBlue;
            this.sidenavbar.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.sidenavbar.Location = new System.Drawing.Point(0, 129);
            this.sidenavbar.Name = "sidenavbar";
            this.sidenavbar.Size = new System.Drawing.Size(146, 514);
            this.sidenavbar.TabIndex = 6;
            // 
            // btnAboutUsPanel
            // 
            this.btnAboutUsPanel.BorderRadius = 5;
            this.btnAboutUsPanel.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnAboutUsPanel.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnAboutUsPanel.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnAboutUsPanel.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnAboutUsPanel.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnAboutUsPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnAboutUsPanel.FillColor = System.Drawing.Color.Teal;
            this.btnAboutUsPanel.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnAboutUsPanel.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnAboutUsPanel.ForeColor = System.Drawing.Color.White;
            this.btnAboutUsPanel.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.btnAboutUsPanel.Location = new System.Drawing.Point(0, 308);
            this.btnAboutUsPanel.Name = "btnAboutUsPanel";
            this.btnAboutUsPanel.Size = new System.Drawing.Size(146, 45);
            this.btnAboutUsPanel.TabIndex = 5;
            this.btnAboutUsPanel.Text = "About Us";
            this.btnAboutUsPanel.Click += new System.EventHandler(this.btnAboutUsPanel_Click);
            // 
            // btnEditProfilePanel
            // 
            this.btnEditProfilePanel.BorderRadius = 5;
            this.btnEditProfilePanel.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnEditProfilePanel.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnEditProfilePanel.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnEditProfilePanel.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnEditProfilePanel.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnEditProfilePanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnEditProfilePanel.FillColor = System.Drawing.Color.Teal;
            this.btnEditProfilePanel.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnEditProfilePanel.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnEditProfilePanel.ForeColor = System.Drawing.Color.White;
            this.btnEditProfilePanel.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.btnEditProfilePanel.Location = new System.Drawing.Point(0, 263);
            this.btnEditProfilePanel.Name = "btnEditProfilePanel";
            this.btnEditProfilePanel.Size = new System.Drawing.Size(146, 45);
            this.btnEditProfilePanel.TabIndex = 4;
            this.btnEditProfilePanel.Text = "Edit Profile";
            this.btnEditProfilePanel.Click += new System.EventHandler(this.btnEditProfilePanel_Click);
            // 
            // btnStatusPanel
            // 
            this.btnStatusPanel.BorderRadius = 5;
            this.btnStatusPanel.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnStatusPanel.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnStatusPanel.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnStatusPanel.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnStatusPanel.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnStatusPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnStatusPanel.FillColor = System.Drawing.Color.Teal;
            this.btnStatusPanel.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnStatusPanel.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnStatusPanel.ForeColor = System.Drawing.Color.White;
            this.btnStatusPanel.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.btnStatusPanel.Location = new System.Drawing.Point(0, 218);
            this.btnStatusPanel.Name = "btnStatusPanel";
            this.btnStatusPanel.Size = new System.Drawing.Size(146, 45);
            this.btnStatusPanel.TabIndex = 2;
            this.btnStatusPanel.Text = "Transaction Status";
            this.btnStatusPanel.Click += new System.EventHandler(this.btnStatusPanel_Click);
            // 
            // btnDropOff
            // 
            this.btnDropOff.BorderRadius = 5;
            this.btnDropOff.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnDropOff.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnDropOff.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnDropOff.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnDropOff.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnDropOff.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnDropOff.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnDropOff.FillColor2 = System.Drawing.Color.Teal;
            this.btnDropOff.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnDropOff.ForeColor = System.Drawing.Color.White;
            this.btnDropOff.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.btnDropOff.Location = new System.Drawing.Point(0, 173);
            this.btnDropOff.Name = "btnDropOff";
            this.btnDropOff.Padding = new System.Windows.Forms.Padding(3);
            this.btnDropOff.Size = new System.Drawing.Size(146, 45);
            this.btnDropOff.TabIndex = 1;
            this.btnDropOff.Text = "Schedule Drop-off";
            this.btnDropOff.Click += new System.EventHandler(this.btnDropOff_Click);
            // 
            // btnProfilename
            // 
            this.btnProfilename.BorderRadius = 5;
            this.btnProfilename.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnProfilename.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnProfilename.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnProfilename.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnProfilename.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnProfilename.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnProfilename.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnProfilename.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btnProfilename.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnProfilename.ForeColor = System.Drawing.Color.White;
            this.btnProfilename.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.btnProfilename.Location = new System.Drawing.Point(0, 134);
            this.btnProfilename.Name = "btnProfilename";
            this.btnProfilename.Size = new System.Drawing.Size(146, 39);
            this.btnProfilename.TabIndex = 3;
            this.btnProfilename.Text = "Firstname Lastname";
            this.btnProfilename.Click += new System.EventHandler(this.btnProfilename_Click);
            // 
            // guna2GradientPanel4
            // 
            this.guna2GradientPanel4.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientPanel4.BorderRadius = 5;
            this.guna2GradientPanel4.Controls.Add(this.pbProfile);
            this.guna2GradientPanel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.guna2GradientPanel4.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(107)))), ((int)(((byte)(139)))));
            this.guna2GradientPanel4.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.guna2GradientPanel4.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.guna2GradientPanel4.Location = new System.Drawing.Point(0, 0);
            this.guna2GradientPanel4.Name = "guna2GradientPanel4";
            this.guna2GradientPanel4.Size = new System.Drawing.Size(146, 134);
            this.guna2GradientPanel4.TabIndex = 0;
            // 
            // pbProfile
            // 
            this.pbProfile.BackColor = System.Drawing.Color.White;
            this.pbProfile.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbProfile.BackgroundImage")));
            this.pbProfile.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbProfile.BorderRadius = 15;
            this.pbProfile.Image = ((System.Drawing.Image)(resources.GetObject("pbProfile.Image")));
            this.pbProfile.ImageRotate = 0F;
            this.pbProfile.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbProfile.InitialImage")));
            this.pbProfile.Location = new System.Drawing.Point(14, 17);
            this.pbProfile.Name = "pbProfile";
            this.pbProfile.Size = new System.Drawing.Size(118, 100);
            this.pbProfile.TabIndex = 0;
            this.pbProfile.TabStop = false;
            // 
            // RequestPanel
            // 
            this.RequestPanel.Controls.Add(this.guna2HtmlLabel8);
            this.RequestPanel.Controls.Add(this.guna2HtmlLabel7);
            this.RequestPanel.Controls.Add(this.guna2HtmlLabel6);
            this.RequestPanel.Controls.Add(this.btnSpecial);
            this.RequestPanel.Controls.Add(this.btnDryClean);
            this.RequestPanel.Controls.Add(this.btnStandard);
            this.RequestPanel.Controls.Add(this.guna2GradientPanel5);
            this.RequestPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.RequestPanel.Location = new System.Drawing.Point(146, 129);
            this.RequestPanel.Name = "RequestPanel";
            this.RequestPanel.Size = new System.Drawing.Size(875, 514);
            this.RequestPanel.TabIndex = 7;
            // 
            // guna2HtmlLabel8
            // 
            this.guna2HtmlLabel8.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel8.Font = new System.Drawing.Font("Segoe UI", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel8.ForeColor = System.Drawing.Color.Teal;
            this.guna2HtmlLabel8.Location = new System.Drawing.Point(636, 199);
            this.guna2HtmlLabel8.Name = "guna2HtmlLabel8";
            this.guna2HtmlLabel8.Size = new System.Drawing.Size(118, 19);
            this.guna2HtmlLabel8.TabIndex = 17;
            this.guna2HtmlLabel8.Text = "Specialty Cleaning";
            // 
            // guna2HtmlLabel7
            // 
            this.guna2HtmlLabel7.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel7.Font = new System.Drawing.Font("Segoe UI", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel7.ForeColor = System.Drawing.Color.Teal;
            this.guna2HtmlLabel7.Location = new System.Drawing.Point(393, 199);
            this.guna2HtmlLabel7.Name = "guna2HtmlLabel7";
            this.guna2HtmlLabel7.Size = new System.Drawing.Size(84, 19);
            this.guna2HtmlLabel7.TabIndex = 16;
            this.guna2HtmlLabel7.Text = "Dry Cleaning";
            // 
            // guna2HtmlLabel6
            // 
            this.guna2HtmlLabel6.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel6.Font = new System.Drawing.Font("Segoe UI", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel6.ForeColor = System.Drawing.Color.Teal;
            this.guna2HtmlLabel6.Location = new System.Drawing.Point(102, 199);
            this.guna2HtmlLabel6.Name = "guna2HtmlLabel6";
            this.guna2HtmlLabel6.Size = new System.Drawing.Size(157, 19);
            this.guna2HtmlLabel6.TabIndex = 15;
            this.guna2HtmlLabel6.Text = "Standard Wash and Fold";
            // 
            // btnSpecial
            // 
            this.btnSpecial.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSpecial.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.btnSpecial.HoverState.ImageSize = new System.Drawing.Size(150, 150);
            this.btnSpecial.Image = ((System.Drawing.Image)(resources.GetObject("btnSpecial.Image")));
            this.btnSpecial.ImageOffset = new System.Drawing.Point(0, 0);
            this.btnSpecial.ImageRotate = 0F;
            this.btnSpecial.ImageSize = new System.Drawing.Size(130, 130);
            this.btnSpecial.Location = new System.Drawing.Point(619, 44);
            this.btnSpecial.Name = "btnSpecial";
            this.btnSpecial.PressedState.ImageSize = new System.Drawing.Size(120, 120);
            this.btnSpecial.Size = new System.Drawing.Size(150, 150);
            this.btnSpecial.TabIndex = 5;
            this.btnSpecial.Click += new System.EventHandler(this.btnSpecial_Click);
            // 
            // btnDryClean
            // 
            this.btnDryClean.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnDryClean.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.btnDryClean.HoverState.ImageSize = new System.Drawing.Size(150, 150);
            this.btnDryClean.Image = ((System.Drawing.Image)(resources.GetObject("btnDryClean.Image")));
            this.btnDryClean.ImageOffset = new System.Drawing.Point(0, 0);
            this.btnDryClean.ImageRotate = 0F;
            this.btnDryClean.ImageSize = new System.Drawing.Size(130, 130);
            this.btnDryClean.Location = new System.Drawing.Point(362, 44);
            this.btnDryClean.Name = "btnDryClean";
            this.btnDryClean.PressedState.ImageSize = new System.Drawing.Size(120, 120);
            this.btnDryClean.Size = new System.Drawing.Size(150, 150);
            this.btnDryClean.TabIndex = 4;
            this.btnDryClean.Click += new System.EventHandler(this.btnDryClean_Click);
            // 
            // btnStandard
            // 
            this.btnStandard.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnStandard.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.btnStandard.HoverState.ImageSize = new System.Drawing.Size(150, 150);
            this.btnStandard.Image = ((System.Drawing.Image)(resources.GetObject("btnStandard.Image")));
            this.btnStandard.ImageOffset = new System.Drawing.Point(0, 0);
            this.btnStandard.ImageRotate = 0F;
            this.btnStandard.ImageSize = new System.Drawing.Size(130, 130);
            this.btnStandard.Location = new System.Drawing.Point(106, 44);
            this.btnStandard.Name = "btnStandard";
            this.btnStandard.PressedState.ImageSize = new System.Drawing.Size(120, 120);
            this.btnStandard.Size = new System.Drawing.Size(150, 150);
            this.btnStandard.TabIndex = 1;
            this.btnStandard.Click += new System.EventHandler(this.btnStandard_Click);
            // 
            // guna2GradientPanel5
            // 
            this.guna2GradientPanel5.Controls.Add(this.SpecialtyCleaningPanel);
            this.guna2GradientPanel5.Controls.Add(this.StandardPanel);
            this.guna2GradientPanel5.Controls.Add(this.DryCleaningPanel);
            this.guna2GradientPanel5.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.guna2GradientPanel5.FillColor = System.Drawing.Color.Azure;
            this.guna2GradientPanel5.FillColor2 = System.Drawing.Color.LightCyan;
            this.guna2GradientPanel5.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.guna2GradientPanel5.Location = new System.Drawing.Point(0, 263);
            this.guna2GradientPanel5.Name = "guna2GradientPanel5";
            this.guna2GradientPanel5.ShadowDecoration.Enabled = true;
            this.guna2GradientPanel5.ShadowDecoration.Shadow = new System.Windows.Forms.Padding(0, 3, 0, 0);
            this.guna2GradientPanel5.Size = new System.Drawing.Size(875, 251);
            this.guna2GradientPanel5.TabIndex = 3;
            // 
            // SpecialtyCleaningPanel
            // 
            this.SpecialtyCleaningPanel.Controls.Add(this.guna2GradientPanel9);
            this.SpecialtyCleaningPanel.Controls.Add(this.guna2HtmlLabel15);
            this.SpecialtyCleaningPanel.Controls.Add(this.checkBoxSpecialStainRemove);
            this.SpecialtyCleaningPanel.Controls.Add(this.guna2HtmlLabel16);
            this.SpecialtyCleaningPanel.Controls.Add(this.checkBoxSpecialFabSoft);
            this.SpecialtyCleaningPanel.Controls.Add(this.guna2HtmlLabel17);
            this.SpecialtyCleaningPanel.Controls.Add(this.checkBoxSpecialHand);
            this.SpecialtyCleaningPanel.Controls.Add(this.guna2HtmlLabel18);
            this.SpecialtyCleaningPanel.Controls.Add(this.checkBoxSpecialEco);
            this.SpecialtyCleaningPanel.Controls.Add(this.guna2HtmlLabel19);
            this.SpecialtyCleaningPanel.Controls.Add(this.checkBoxSpecialAntiBac);
            this.SpecialtyCleaningPanel.Controls.Add(this.guna2HtmlLabel20);
            this.SpecialtyCleaningPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.SpecialtyCleaningPanel.Location = new System.Drawing.Point(0, 0);
            this.SpecialtyCleaningPanel.Name = "SpecialtyCleaningPanel";
            this.SpecialtyCleaningPanel.Size = new System.Drawing.Size(875, 251);
            this.SpecialtyCleaningPanel.TabIndex = 31;
            this.SpecialtyCleaningPanel.Visible = false;
            // 
            // guna2GradientPanel9
            // 
            this.guna2GradientPanel9.Controls.Add(this.txtSpecialtyTotalPrice);
            this.guna2GradientPanel9.Controls.Add(this.btnSpecialtyAddTransaction);
            this.guna2GradientPanel9.Controls.Add(this.numUpSpecialLoad);
            this.guna2GradientPanel9.Dock = System.Windows.Forms.DockStyle.Right;
            this.guna2GradientPanel9.Location = new System.Drawing.Point(590, 0);
            this.guna2GradientPanel9.Name = "guna2GradientPanel9";
            this.guna2GradientPanel9.Size = new System.Drawing.Size(285, 251);
            this.guna2GradientPanel9.TabIndex = 29;
            // 
            // txtSpecialtyTotalPrice
            // 
            this.txtSpecialtyTotalPrice.Location = new System.Drawing.Point(46, 45);
            this.txtSpecialtyTotalPrice.Name = "txtSpecialtyTotalPrice";
            this.txtSpecialtyTotalPrice.ReadOnly = true;
            this.txtSpecialtyTotalPrice.Size = new System.Drawing.Size(207, 34);
            this.txtSpecialtyTotalPrice.TabIndex = 29;
            this.txtSpecialtyTotalPrice.Text = "Total Price: ₱250.00";
            // 
            // btnSpecialtyAddTransaction
            // 
            this.btnSpecialtyAddTransaction.BorderRadius = 5;
            this.btnSpecialtyAddTransaction.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnSpecialtyAddTransaction.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnSpecialtyAddTransaction.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnSpecialtyAddTransaction.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnSpecialtyAddTransaction.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnSpecialtyAddTransaction.FillColor = System.Drawing.Color.Teal;
            this.btnSpecialtyAddTransaction.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnSpecialtyAddTransaction.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnSpecialtyAddTransaction.ForeColor = System.Drawing.Color.White;
            this.btnSpecialtyAddTransaction.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.btnSpecialtyAddTransaction.Location = new System.Drawing.Point(67, 175);
            this.btnSpecialtyAddTransaction.Name = "btnSpecialtyAddTransaction";
            this.btnSpecialtyAddTransaction.Size = new System.Drawing.Size(146, 35);
            this.btnSpecialtyAddTransaction.TabIndex = 9;
            this.btnSpecialtyAddTransaction.Text = "Schedule Drop-off";
            this.btnSpecialtyAddTransaction.Click += new System.EventHandler(this.btnSpecialtyAddTransaction_Click);
            // 
            // numUpSpecialLoad
            // 
            this.numUpSpecialLoad.BackColor = System.Drawing.Color.Transparent;
            this.numUpSpecialLoad.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.numUpSpecialLoad.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.numUpSpecialLoad.Location = new System.Drawing.Point(93, 119);
            this.numUpSpecialLoad.Name = "numUpSpecialLoad";
            this.numUpSpecialLoad.Size = new System.Drawing.Size(100, 23);
            this.numUpSpecialLoad.TabIndex = 28;
            this.numUpSpecialLoad.UpDownButtonFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.numUpSpecialLoad.ValueChanged += new System.EventHandler(this.numUpSpecialLoad_ValueChanged);
            // 
            // guna2HtmlLabel15
            // 
            this.guna2HtmlLabel15.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel15.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel15.ForeColor = System.Drawing.Color.Teal;
            this.guna2HtmlLabel15.Location = new System.Drawing.Point(370, 124);
            this.guna2HtmlLabel15.Name = "guna2HtmlLabel15";
            this.guna2HtmlLabel15.Size = new System.Drawing.Size(135, 19);
            this.guna2HtmlLabel15.TabIndex = 26;
            this.guna2HtmlLabel15.Text = "Stain Removal: ₱60.00";
            // 
            // checkBoxSpecialStainRemove
            // 
            this.checkBoxSpecialStainRemove.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.checkBoxSpecialStainRemove.CheckedState.BorderRadius = 2;
            this.checkBoxSpecialStainRemove.CheckedState.BorderThickness = 0;
            this.checkBoxSpecialStainRemove.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.checkBoxSpecialStainRemove.CheckMarkColor = System.Drawing.SystemColors.ActiveCaption;
            this.checkBoxSpecialStainRemove.Location = new System.Drawing.Point(330, 123);
            this.checkBoxSpecialStainRemove.Name = "checkBoxSpecialStainRemove";
            this.checkBoxSpecialStainRemove.Size = new System.Drawing.Size(20, 20);
            this.checkBoxSpecialStainRemove.TabIndex = 27;
            this.checkBoxSpecialStainRemove.Text = "guna2CustomCheckBox5";
            this.checkBoxSpecialStainRemove.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.checkBoxSpecialStainRemove.UncheckedState.BorderRadius = 2;
            this.checkBoxSpecialStainRemove.UncheckedState.BorderThickness = 1;
            this.checkBoxSpecialStainRemove.UncheckedState.FillColor = System.Drawing.Color.White;
            this.checkBoxSpecialStainRemove.Click += new System.EventHandler(this.checkBoxSpecialStainRemove_Click);
            // 
            // guna2HtmlLabel16
            // 
            this.guna2HtmlLabel16.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel16.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel16.ForeColor = System.Drawing.Color.Teal;
            this.guna2HtmlLabel16.Location = new System.Drawing.Point(370, 86);
            this.guna2HtmlLabel16.Name = "guna2HtmlLabel16";
            this.guna2HtmlLabel16.Size = new System.Drawing.Size(140, 19);
            this.guna2HtmlLabel16.TabIndex = 24;
            this.guna2HtmlLabel16.Text = "Fabric Softener: ₱25.00";
            // 
            // checkBoxSpecialFabSoft
            // 
            this.checkBoxSpecialFabSoft.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.checkBoxSpecialFabSoft.CheckedState.BorderRadius = 2;
            this.checkBoxSpecialFabSoft.CheckedState.BorderThickness = 0;
            this.checkBoxSpecialFabSoft.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.checkBoxSpecialFabSoft.CheckMarkColor = System.Drawing.SystemColors.ActiveCaption;
            this.checkBoxSpecialFabSoft.Location = new System.Drawing.Point(330, 85);
            this.checkBoxSpecialFabSoft.Name = "checkBoxSpecialFabSoft";
            this.checkBoxSpecialFabSoft.Size = new System.Drawing.Size(20, 20);
            this.checkBoxSpecialFabSoft.TabIndex = 25;
            this.checkBoxSpecialFabSoft.Text = "guna2CustomCheckBox4";
            this.checkBoxSpecialFabSoft.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.checkBoxSpecialFabSoft.UncheckedState.BorderRadius = 2;
            this.checkBoxSpecialFabSoft.UncheckedState.BorderThickness = 1;
            this.checkBoxSpecialFabSoft.UncheckedState.FillColor = System.Drawing.Color.White;
            this.checkBoxSpecialFabSoft.Click += new System.EventHandler(this.checkBoxSpecialFabSoft_Click);
            // 
            // guna2HtmlLabel17
            // 
            this.guna2HtmlLabel17.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel17.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel17.ForeColor = System.Drawing.Color.Teal;
            this.guna2HtmlLabel17.Location = new System.Drawing.Point(106, 165);
            this.guna2HtmlLabel17.Name = "guna2HtmlLabel17";
            this.guna2HtmlLabel17.Size = new System.Drawing.Size(140, 19);
            this.guna2HtmlLabel17.TabIndex = 22;
            this.guna2HtmlLabel17.Text = "Hand Finishing: ₱70.00";
            // 
            // checkBoxSpecialHand
            // 
            this.checkBoxSpecialHand.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.checkBoxSpecialHand.CheckedState.BorderRadius = 2;
            this.checkBoxSpecialHand.CheckedState.BorderThickness = 0;
            this.checkBoxSpecialHand.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.checkBoxSpecialHand.CheckMarkColor = System.Drawing.SystemColors.ActiveCaption;
            this.checkBoxSpecialHand.Location = new System.Drawing.Point(66, 164);
            this.checkBoxSpecialHand.Name = "checkBoxSpecialHand";
            this.checkBoxSpecialHand.Size = new System.Drawing.Size(20, 20);
            this.checkBoxSpecialHand.TabIndex = 23;
            this.checkBoxSpecialHand.Text = "guna2CustomCheckBox3";
            this.checkBoxSpecialHand.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.checkBoxSpecialHand.UncheckedState.BorderRadius = 2;
            this.checkBoxSpecialHand.UncheckedState.BorderThickness = 1;
            this.checkBoxSpecialHand.UncheckedState.FillColor = System.Drawing.Color.White;
            this.checkBoxSpecialHand.Click += new System.EventHandler(this.checkBoxSpecialHand_Click);
            // 
            // guna2HtmlLabel18
            // 
            this.guna2HtmlLabel18.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel18.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel18.ForeColor = System.Drawing.Color.Teal;
            this.guna2HtmlLabel18.Location = new System.Drawing.Point(106, 85);
            this.guna2HtmlLabel18.Name = "guna2HtmlLabel18";
            this.guna2HtmlLabel18.Size = new System.Drawing.Size(192, 19);
            this.guna2HtmlLabel18.TabIndex = 20;
            this.guna2HtmlLabel18.Text = "Antibacterial Treatment: ₱30.00";
            // 
            // checkBoxSpecialEco
            // 
            this.checkBoxSpecialEco.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.checkBoxSpecialEco.CheckedState.BorderRadius = 2;
            this.checkBoxSpecialEco.CheckedState.BorderThickness = 0;
            this.checkBoxSpecialEco.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.checkBoxSpecialEco.CheckMarkColor = System.Drawing.SystemColors.ActiveCaption;
            this.checkBoxSpecialEco.Location = new System.Drawing.Point(66, 123);
            this.checkBoxSpecialEco.Name = "checkBoxSpecialEco";
            this.checkBoxSpecialEco.Size = new System.Drawing.Size(20, 20);
            this.checkBoxSpecialEco.TabIndex = 21;
            this.checkBoxSpecialEco.Text = "guna2CustomCheckBox2";
            this.checkBoxSpecialEco.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.checkBoxSpecialEco.UncheckedState.BorderRadius = 2;
            this.checkBoxSpecialEco.UncheckedState.BorderThickness = 1;
            this.checkBoxSpecialEco.UncheckedState.FillColor = System.Drawing.Color.White;
            this.checkBoxSpecialEco.Click += new System.EventHandler(this.checkBoxSpecialEco_Click);
            // 
            // guna2HtmlLabel19
            // 
            this.guna2HtmlLabel19.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel19.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel19.ForeColor = System.Drawing.Color.Teal;
            this.guna2HtmlLabel19.Location = new System.Drawing.Point(106, 123);
            this.guna2HtmlLabel19.Name = "guna2HtmlLabel19";
            this.guna2HtmlLabel19.Size = new System.Drawing.Size(161, 19);
            this.guna2HtmlLabel19.TabIndex = 18;
            this.guna2HtmlLabel19.Text = "Eco-Friendly Wash: ₱40.00";
            // 
            // checkBoxSpecialAntiBac
            // 
            this.checkBoxSpecialAntiBac.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.checkBoxSpecialAntiBac.CheckedState.BorderRadius = 2;
            this.checkBoxSpecialAntiBac.CheckedState.BorderThickness = 0;
            this.checkBoxSpecialAntiBac.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.checkBoxSpecialAntiBac.CheckMarkColor = System.Drawing.SystemColors.ActiveCaption;
            this.checkBoxSpecialAntiBac.Location = new System.Drawing.Point(66, 85);
            this.checkBoxSpecialAntiBac.Name = "checkBoxSpecialAntiBac";
            this.checkBoxSpecialAntiBac.Size = new System.Drawing.Size(20, 20);
            this.checkBoxSpecialAntiBac.TabIndex = 19;
            this.checkBoxSpecialAntiBac.Text = "guna2CustomCheckBox1";
            this.checkBoxSpecialAntiBac.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.checkBoxSpecialAntiBac.UncheckedState.BorderRadius = 2;
            this.checkBoxSpecialAntiBac.UncheckedState.BorderThickness = 1;
            this.checkBoxSpecialAntiBac.UncheckedState.FillColor = System.Drawing.Color.White;
            this.checkBoxSpecialAntiBac.Click += new System.EventHandler(this.checkBoxSpecialAntiBac_Click);
            // 
            // guna2HtmlLabel20
            // 
            this.guna2HtmlLabel20.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel20.Font = new System.Drawing.Font("Segoe UI", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel20.ForeColor = System.Drawing.Color.Teal;
            this.guna2HtmlLabel20.Location = new System.Drawing.Point(198, 13);
            this.guna2HtmlLabel20.Name = "guna2HtmlLabel20";
            this.guna2HtmlLabel20.Size = new System.Drawing.Size(186, 32);
            this.guna2HtmlLabel20.TabIndex = 18;
            this.guna2HtmlLabel20.Text = "Specialty Cleaning";
            // 
            // StandardPanel
            // 
            this.StandardPanel.Controls.Add(this.guna2GradientPanel6);
            this.StandardPanel.Controls.Add(this.guna2HtmlLabel10);
            this.StandardPanel.Controls.Add(this.checkBoxGentWash);
            this.StandardPanel.Controls.Add(this.oy);
            this.StandardPanel.Controls.Add(this.checkBoxFabSoft);
            this.StandardPanel.Controls.Add(this.guna2HtmlLabel5);
            this.StandardPanel.Controls.Add(this.checkBoxScent);
            this.StandardPanel.Controls.Add(this.oi);
            this.StandardPanel.Controls.Add(this.checkBoxIron);
            this.StandardPanel.Controls.Add(this.guna2HtmlLabel3);
            this.StandardPanel.Controls.Add(this.checkBoxAntiBac);
            this.StandardPanel.Controls.Add(this.guna2HtmlLabel2);
            this.StandardPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.StandardPanel.Location = new System.Drawing.Point(0, 0);
            this.StandardPanel.Name = "StandardPanel";
            this.StandardPanel.Size = new System.Drawing.Size(875, 251);
            this.StandardPanel.TabIndex = 18;
            this.StandardPanel.Visible = false;
            // 
            // guna2GradientPanel6
            // 
            this.guna2GradientPanel6.Controls.Add(this.txtStandardTotal);
            this.guna2GradientPanel6.Controls.Add(this.btnStandardAddTransaction);
            this.guna2GradientPanel6.Controls.Add(this.numUpLoad);
            this.guna2GradientPanel6.Dock = System.Windows.Forms.DockStyle.Right;
            this.guna2GradientPanel6.Location = new System.Drawing.Point(590, 0);
            this.guna2GradientPanel6.Name = "guna2GradientPanel6";
            this.guna2GradientPanel6.Size = new System.Drawing.Size(285, 251);
            this.guna2GradientPanel6.TabIndex = 29;
            // 
            // txtStandardTotal
            // 
            this.txtStandardTotal.Location = new System.Drawing.Point(46, 45);
            this.txtStandardTotal.Name = "txtStandardTotal";
            this.txtStandardTotal.ReadOnly = true;
            this.txtStandardTotal.Size = new System.Drawing.Size(207, 34);
            this.txtStandardTotal.TabIndex = 29;
            this.txtStandardTotal.Text = "Total Price: ₱100.00";
            // 
            // btnStandardAddTransaction
            // 
            this.btnStandardAddTransaction.BorderRadius = 5;
            this.btnStandardAddTransaction.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnStandardAddTransaction.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnStandardAddTransaction.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnStandardAddTransaction.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnStandardAddTransaction.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnStandardAddTransaction.FillColor = System.Drawing.Color.Teal;
            this.btnStandardAddTransaction.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnStandardAddTransaction.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnStandardAddTransaction.ForeColor = System.Drawing.Color.White;
            this.btnStandardAddTransaction.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.btnStandardAddTransaction.Location = new System.Drawing.Point(67, 175);
            this.btnStandardAddTransaction.Name = "btnStandardAddTransaction";
            this.btnStandardAddTransaction.Size = new System.Drawing.Size(146, 35);
            this.btnStandardAddTransaction.TabIndex = 9;
            this.btnStandardAddTransaction.Text = "Schedule Drop-off";
            this.btnStandardAddTransaction.Click += new System.EventHandler(this.btnStandardAddTransaction_Click);
            // 
            // numUpLoad
            // 
            this.numUpLoad.BackColor = System.Drawing.Color.Transparent;
            this.numUpLoad.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.numUpLoad.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.numUpLoad.Location = new System.Drawing.Point(93, 119);
            this.numUpLoad.Name = "numUpLoad";
            this.numUpLoad.Size = new System.Drawing.Size(100, 23);
            this.numUpLoad.TabIndex = 28;
            this.numUpLoad.UpDownButtonFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.numUpLoad.ValueChanged += new System.EventHandler(this.numUpLoad_ValueChanged);
            // 
            // guna2HtmlLabel10
            // 
            this.guna2HtmlLabel10.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel10.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel10.ForeColor = System.Drawing.Color.Teal;
            this.guna2HtmlLabel10.Location = new System.Drawing.Point(106, 85);
            this.guna2HtmlLabel10.Name = "guna2HtmlLabel10";
            this.guna2HtmlLabel10.Size = new System.Drawing.Size(190, 19);
            this.guna2HtmlLabel10.TabIndex = 26;
            this.guna2HtmlLabel10.Text = "Antibacterial Treatment: ₱15.00";
            // 
            // checkBoxGentWash
            // 
            this.checkBoxGentWash.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.checkBoxGentWash.CheckedState.BorderRadius = 2;
            this.checkBoxGentWash.CheckedState.BorderThickness = 0;
            this.checkBoxGentWash.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.checkBoxGentWash.CheckMarkColor = System.Drawing.SystemColors.ActiveCaption;
            this.checkBoxGentWash.Location = new System.Drawing.Point(330, 123);
            this.checkBoxGentWash.Name = "checkBoxGentWash";
            this.checkBoxGentWash.Size = new System.Drawing.Size(20, 20);
            this.checkBoxGentWash.TabIndex = 27;
            this.checkBoxGentWash.Text = "guna2CustomCheckBox5";
            this.checkBoxGentWash.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.checkBoxGentWash.UncheckedState.BorderRadius = 2;
            this.checkBoxGentWash.UncheckedState.BorderThickness = 1;
            this.checkBoxGentWash.UncheckedState.FillColor = System.Drawing.Color.White;
            this.checkBoxGentWash.Click += new System.EventHandler(this.checkBoxGentWash_Click);
            // 
            // oy
            // 
            this.oy.BackColor = System.Drawing.Color.Transparent;
            this.oy.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.oy.ForeColor = System.Drawing.Color.Teal;
            this.oy.Location = new System.Drawing.Point(370, 86);
            this.oy.Name = "oy";
            this.oy.Size = new System.Drawing.Size(138, 19);
            this.oy.TabIndex = 24;
            this.oy.Text = "Fabric Softener: ₱10.00";
            // 
            // checkBoxFabSoft
            // 
            this.checkBoxFabSoft.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.checkBoxFabSoft.CheckedState.BorderRadius = 2;
            this.checkBoxFabSoft.CheckedState.BorderThickness = 0;
            this.checkBoxFabSoft.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.checkBoxFabSoft.CheckMarkColor = System.Drawing.SystemColors.ActiveCaption;
            this.checkBoxFabSoft.Location = new System.Drawing.Point(330, 85);
            this.checkBoxFabSoft.Name = "checkBoxFabSoft";
            this.checkBoxFabSoft.Size = new System.Drawing.Size(20, 20);
            this.checkBoxFabSoft.TabIndex = 25;
            this.checkBoxFabSoft.Text = "guna2CustomCheckBox4";
            this.checkBoxFabSoft.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.checkBoxFabSoft.UncheckedState.BorderRadius = 2;
            this.checkBoxFabSoft.UncheckedState.BorderThickness = 1;
            this.checkBoxFabSoft.UncheckedState.FillColor = System.Drawing.Color.White;
            this.checkBoxFabSoft.Click += new System.EventHandler(this.checkBoxFabSoft_Click);
            // 
            // guna2HtmlLabel5
            // 
            this.guna2HtmlLabel5.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel5.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel5.ForeColor = System.Drawing.Color.Teal;
            this.guna2HtmlLabel5.Location = new System.Drawing.Point(106, 165);
            this.guna2HtmlLabel5.Name = "guna2HtmlLabel5";
            this.guna2HtmlLabel5.Size = new System.Drawing.Size(136, 19);
            this.guna2HtmlLabel5.TabIndex = 22;
            this.guna2HtmlLabel5.Text = "Scented Finish: ₱20.00";
            // 
            // checkBoxScent
            // 
            this.checkBoxScent.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.checkBoxScent.CheckedState.BorderRadius = 2;
            this.checkBoxScent.CheckedState.BorderThickness = 0;
            this.checkBoxScent.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.checkBoxScent.CheckMarkColor = System.Drawing.SystemColors.ActiveCaption;
            this.checkBoxScent.Location = new System.Drawing.Point(66, 164);
            this.checkBoxScent.Name = "checkBoxScent";
            this.checkBoxScent.Size = new System.Drawing.Size(20, 20);
            this.checkBoxScent.TabIndex = 23;
            this.checkBoxScent.Text = "guna2CustomCheckBox3";
            this.checkBoxScent.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.checkBoxScent.UncheckedState.BorderRadius = 2;
            this.checkBoxScent.UncheckedState.BorderThickness = 1;
            this.checkBoxScent.UncheckedState.FillColor = System.Drawing.Color.White;
            this.checkBoxScent.Click += new System.EventHandler(this.checkBoxScent_Click);
            // 
            // oi
            // 
            this.oi.BackColor = System.Drawing.Color.Transparent;
            this.oi.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.oi.ForeColor = System.Drawing.Color.Teal;
            this.oi.Location = new System.Drawing.Point(370, 124);
            this.oi.Name = "oi";
            this.oi.Size = new System.Drawing.Size(126, 19);
            this.oi.TabIndex = 20;
            this.oi.Text = "Gentle Wash: ₱20.00";
            // 
            // checkBoxIron
            // 
            this.checkBoxIron.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.checkBoxIron.CheckedState.BorderRadius = 2;
            this.checkBoxIron.CheckedState.BorderThickness = 0;
            this.checkBoxIron.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.checkBoxIron.CheckMarkColor = System.Drawing.SystemColors.ActiveCaption;
            this.checkBoxIron.Location = new System.Drawing.Point(66, 123);
            this.checkBoxIron.Name = "checkBoxIron";
            this.checkBoxIron.Size = new System.Drawing.Size(20, 20);
            this.checkBoxIron.TabIndex = 21;
            this.checkBoxIron.Text = "guna2CustomCheckBox2";
            this.checkBoxIron.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.checkBoxIron.UncheckedState.BorderRadius = 2;
            this.checkBoxIron.UncheckedState.BorderThickness = 1;
            this.checkBoxIron.UncheckedState.FillColor = System.Drawing.Color.White;
            this.checkBoxIron.Click += new System.EventHandler(this.checkBoxIron_Click);
            // 
            // guna2HtmlLabel3
            // 
            this.guna2HtmlLabel3.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel3.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel3.ForeColor = System.Drawing.Color.Teal;
            this.guna2HtmlLabel3.Location = new System.Drawing.Point(106, 123);
            this.guna2HtmlLabel3.Name = "guna2HtmlLabel3";
            this.guna2HtmlLabel3.Size = new System.Drawing.Size(93, 19);
            this.guna2HtmlLabel3.TabIndex = 18;
            this.guna2HtmlLabel3.Text = "Ironing: ₱30.00";
            // 
            // checkBoxAntiBac
            // 
            this.checkBoxAntiBac.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.checkBoxAntiBac.CheckedState.BorderRadius = 2;
            this.checkBoxAntiBac.CheckedState.BorderThickness = 0;
            this.checkBoxAntiBac.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.checkBoxAntiBac.CheckMarkColor = System.Drawing.SystemColors.ActiveCaption;
            this.checkBoxAntiBac.Location = new System.Drawing.Point(66, 85);
            this.checkBoxAntiBac.Name = "checkBoxAntiBac";
            this.checkBoxAntiBac.Size = new System.Drawing.Size(20, 20);
            this.checkBoxAntiBac.TabIndex = 19;
            this.checkBoxAntiBac.Text = "guna2CustomCheckBox1";
            this.checkBoxAntiBac.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.checkBoxAntiBac.UncheckedState.BorderRadius = 2;
            this.checkBoxAntiBac.UncheckedState.BorderThickness = 1;
            this.checkBoxAntiBac.UncheckedState.FillColor = System.Drawing.Color.White;
            this.checkBoxAntiBac.Click += new System.EventHandler(this.checkBoxAntiBac_Click);
            // 
            // guna2HtmlLabel2
            // 
            this.guna2HtmlLabel2.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel2.Font = new System.Drawing.Font("Segoe UI", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel2.ForeColor = System.Drawing.Color.Teal;
            this.guna2HtmlLabel2.Location = new System.Drawing.Point(198, 13);
            this.guna2HtmlLabel2.Name = "guna2HtmlLabel2";
            this.guna2HtmlLabel2.Size = new System.Drawing.Size(152, 32);
            this.guna2HtmlLabel2.TabIndex = 18;
            this.guna2HtmlLabel2.Text = "Standard Wash";
            // 
            // DryCleaningPanel
            // 
            this.DryCleaningPanel.Controls.Add(this.guna2GradientPanel8);
            this.DryCleaningPanel.Controls.Add(this.guna2HtmlLabel4);
            this.DryCleaningPanel.Controls.Add(this.checkBoxDelCare);
            this.DryCleaningPanel.Controls.Add(this.guna2HtmlLabel9);
            this.DryCleaningPanel.Controls.Add(this.checkBoxDryFabSoft);
            this.DryCleaningPanel.Controls.Add(this.guna2HtmlLabel11);
            this.DryCleaningPanel.Controls.Add(this.checkBoxDryMinorRepair);
            this.DryCleaningPanel.Controls.Add(this.guna2HtmlLabel12);
            this.DryCleaningPanel.Controls.Add(this.checkBoxDryPress);
            this.DryCleaningPanel.Controls.Add(this.guna2HtmlLabel13);
            this.DryCleaningPanel.Controls.Add(this.checkBoxDryAntiBac);
            this.DryCleaningPanel.Controls.Add(this.guna2HtmlLabel14);
            this.DryCleaningPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DryCleaningPanel.Location = new System.Drawing.Point(0, 0);
            this.DryCleaningPanel.Name = "DryCleaningPanel";
            this.DryCleaningPanel.Size = new System.Drawing.Size(875, 251);
            this.DryCleaningPanel.TabIndex = 30;
            this.DryCleaningPanel.Visible = false;
            // 
            // guna2GradientPanel8
            // 
            this.guna2GradientPanel8.Controls.Add(this.txtDryTotalPrice);
            this.guna2GradientPanel8.Controls.Add(this.btnDryAddTransaction);
            this.guna2GradientPanel8.Controls.Add(this.numUpDryLoad);
            this.guna2GradientPanel8.Dock = System.Windows.Forms.DockStyle.Right;
            this.guna2GradientPanel8.Location = new System.Drawing.Point(590, 0);
            this.guna2GradientPanel8.Name = "guna2GradientPanel8";
            this.guna2GradientPanel8.Size = new System.Drawing.Size(285, 251);
            this.guna2GradientPanel8.TabIndex = 29;
            // 
            // txtDryTotalPrice
            // 
            this.txtDryTotalPrice.Location = new System.Drawing.Point(46, 45);
            this.txtDryTotalPrice.Name = "txtDryTotalPrice";
            this.txtDryTotalPrice.ReadOnly = true;
            this.txtDryTotalPrice.Size = new System.Drawing.Size(207, 34);
            this.txtDryTotalPrice.TabIndex = 29;
            this.txtDryTotalPrice.Text = "Total Price: ₱200.00";
            // 
            // btnDryAddTransaction
            // 
            this.btnDryAddTransaction.BorderRadius = 5;
            this.btnDryAddTransaction.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnDryAddTransaction.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnDryAddTransaction.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnDryAddTransaction.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnDryAddTransaction.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnDryAddTransaction.FillColor = System.Drawing.Color.Teal;
            this.btnDryAddTransaction.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnDryAddTransaction.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnDryAddTransaction.ForeColor = System.Drawing.Color.White;
            this.btnDryAddTransaction.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.btnDryAddTransaction.Location = new System.Drawing.Point(67, 175);
            this.btnDryAddTransaction.Name = "btnDryAddTransaction";
            this.btnDryAddTransaction.Size = new System.Drawing.Size(146, 35);
            this.btnDryAddTransaction.TabIndex = 9;
            this.btnDryAddTransaction.Text = "Schedule Drop-off";
            this.btnDryAddTransaction.Click += new System.EventHandler(this.btnDryAddTransaction_Click);
            // 
            // numUpDryLoad
            // 
            this.numUpDryLoad.BackColor = System.Drawing.Color.Transparent;
            this.numUpDryLoad.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.numUpDryLoad.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.numUpDryLoad.Location = new System.Drawing.Point(93, 119);
            this.numUpDryLoad.Name = "numUpDryLoad";
            this.numUpDryLoad.Size = new System.Drawing.Size(100, 23);
            this.numUpDryLoad.TabIndex = 28;
            this.numUpDryLoad.UpDownButtonFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.numUpDryLoad.ValueChanged += new System.EventHandler(this.numUpDryLoad_ValueChanged);
            // 
            // guna2HtmlLabel4
            // 
            this.guna2HtmlLabel4.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel4.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel4.ForeColor = System.Drawing.Color.Teal;
            this.guna2HtmlLabel4.Location = new System.Drawing.Point(370, 124);
            this.guna2HtmlLabel4.Name = "guna2HtmlLabel4";
            this.guna2HtmlLabel4.Size = new System.Drawing.Size(127, 19);
            this.guna2HtmlLabel4.TabIndex = 26;
            this.guna2HtmlLabel4.Text = "Delicate Care: ₱50.00";
            // 
            // checkBoxDelCare
            // 
            this.checkBoxDelCare.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.checkBoxDelCare.CheckedState.BorderRadius = 2;
            this.checkBoxDelCare.CheckedState.BorderThickness = 0;
            this.checkBoxDelCare.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.checkBoxDelCare.CheckMarkColor = System.Drawing.SystemColors.ActiveCaption;
            this.checkBoxDelCare.Location = new System.Drawing.Point(330, 123);
            this.checkBoxDelCare.Name = "checkBoxDelCare";
            this.checkBoxDelCare.Size = new System.Drawing.Size(20, 20);
            this.checkBoxDelCare.TabIndex = 27;
            this.checkBoxDelCare.Text = "guna2CustomCheckBox5";
            this.checkBoxDelCare.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.checkBoxDelCare.UncheckedState.BorderRadius = 2;
            this.checkBoxDelCare.UncheckedState.BorderThickness = 1;
            this.checkBoxDelCare.UncheckedState.FillColor = System.Drawing.Color.White;
            this.checkBoxDelCare.Click += new System.EventHandler(this.checkBoxDelCare_Click);
            // 
            // guna2HtmlLabel9
            // 
            this.guna2HtmlLabel9.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel9.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel9.ForeColor = System.Drawing.Color.Teal;
            this.guna2HtmlLabel9.Location = new System.Drawing.Point(370, 86);
            this.guna2HtmlLabel9.Name = "guna2HtmlLabel9";
            this.guna2HtmlLabel9.Size = new System.Drawing.Size(140, 19);
            this.guna2HtmlLabel9.TabIndex = 24;
            this.guna2HtmlLabel9.Text = "Fabric Softener: ₱20.00";
            // 
            // checkBoxDryFabSoft
            // 
            this.checkBoxDryFabSoft.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.checkBoxDryFabSoft.CheckedState.BorderRadius = 2;
            this.checkBoxDryFabSoft.CheckedState.BorderThickness = 0;
            this.checkBoxDryFabSoft.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.checkBoxDryFabSoft.CheckMarkColor = System.Drawing.SystemColors.ActiveCaption;
            this.checkBoxDryFabSoft.Location = new System.Drawing.Point(330, 85);
            this.checkBoxDryFabSoft.Name = "checkBoxDryFabSoft";
            this.checkBoxDryFabSoft.Size = new System.Drawing.Size(20, 20);
            this.checkBoxDryFabSoft.TabIndex = 25;
            this.checkBoxDryFabSoft.Text = "guna2CustomCheckBox4";
            this.checkBoxDryFabSoft.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.checkBoxDryFabSoft.UncheckedState.BorderRadius = 2;
            this.checkBoxDryFabSoft.UncheckedState.BorderThickness = 1;
            this.checkBoxDryFabSoft.UncheckedState.FillColor = System.Drawing.Color.White;
            this.checkBoxDryFabSoft.Click += new System.EventHandler(this.checkBoxDryFabSoft_Click);
            // 
            // guna2HtmlLabel11
            // 
            this.guna2HtmlLabel11.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel11.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel11.ForeColor = System.Drawing.Color.Teal;
            this.guna2HtmlLabel11.Location = new System.Drawing.Point(106, 165);
            this.guna2HtmlLabel11.Name = "guna2HtmlLabel11";
            this.guna2HtmlLabel11.Size = new System.Drawing.Size(133, 19);
            this.guna2HtmlLabel11.TabIndex = 22;
            this.guna2HtmlLabel11.Text = "Minor Repairs: ₱40.00";
            // 
            // checkBoxDryMinorRepair
            // 
            this.checkBoxDryMinorRepair.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.checkBoxDryMinorRepair.CheckedState.BorderRadius = 2;
            this.checkBoxDryMinorRepair.CheckedState.BorderThickness = 0;
            this.checkBoxDryMinorRepair.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.checkBoxDryMinorRepair.CheckMarkColor = System.Drawing.SystemColors.ActiveCaption;
            this.checkBoxDryMinorRepair.Location = new System.Drawing.Point(66, 164);
            this.checkBoxDryMinorRepair.Name = "checkBoxDryMinorRepair";
            this.checkBoxDryMinorRepair.Size = new System.Drawing.Size(20, 20);
            this.checkBoxDryMinorRepair.TabIndex = 23;
            this.checkBoxDryMinorRepair.Text = "guna2CustomCheckBox3";
            this.checkBoxDryMinorRepair.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.checkBoxDryMinorRepair.UncheckedState.BorderRadius = 2;
            this.checkBoxDryMinorRepair.UncheckedState.BorderThickness = 1;
            this.checkBoxDryMinorRepair.UncheckedState.FillColor = System.Drawing.Color.White;
            this.checkBoxDryMinorRepair.Click += new System.EventHandler(this.checkBoxDryMinorRepair_Click);
            // 
            // guna2HtmlLabel12
            // 
            this.guna2HtmlLabel12.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel12.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel12.ForeColor = System.Drawing.Color.Teal;
            this.guna2HtmlLabel12.Location = new System.Drawing.Point(106, 85);
            this.guna2HtmlLabel12.Name = "guna2HtmlLabel12";
            this.guna2HtmlLabel12.Size = new System.Drawing.Size(192, 19);
            this.guna2HtmlLabel12.TabIndex = 20;
            this.guna2HtmlLabel12.Text = "Antibacterial Treatment: ₱25.00";
            // 
            // checkBoxDryPress
            // 
            this.checkBoxDryPress.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.checkBoxDryPress.CheckedState.BorderRadius = 2;
            this.checkBoxDryPress.CheckedState.BorderThickness = 0;
            this.checkBoxDryPress.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.checkBoxDryPress.CheckMarkColor = System.Drawing.SystemColors.ActiveCaption;
            this.checkBoxDryPress.Location = new System.Drawing.Point(66, 123);
            this.checkBoxDryPress.Name = "checkBoxDryPress";
            this.checkBoxDryPress.Size = new System.Drawing.Size(20, 20);
            this.checkBoxDryPress.TabIndex = 21;
            this.checkBoxDryPress.Text = "guna2CustomCheckBox2";
            this.checkBoxDryPress.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.checkBoxDryPress.UncheckedState.BorderRadius = 2;
            this.checkBoxDryPress.UncheckedState.BorderThickness = 1;
            this.checkBoxDryPress.UncheckedState.FillColor = System.Drawing.Color.White;
            this.checkBoxDryPress.Click += new System.EventHandler(this.checkBoxDryPress_Click);
            // 
            // guna2HtmlLabel13
            // 
            this.guna2HtmlLabel13.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel13.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel13.ForeColor = System.Drawing.Color.Teal;
            this.guna2HtmlLabel13.Location = new System.Drawing.Point(106, 123);
            this.guna2HtmlLabel13.Name = "guna2HtmlLabel13";
            this.guna2HtmlLabel13.Size = new System.Drawing.Size(174, 19);
            this.guna2HtmlLabel13.TabIndex = 18;
            this.guna2HtmlLabel13.Text = "Pressing & Steaming: ₱30.00";
            // 
            // checkBoxDryAntiBac
            // 
            this.checkBoxDryAntiBac.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.checkBoxDryAntiBac.CheckedState.BorderRadius = 2;
            this.checkBoxDryAntiBac.CheckedState.BorderThickness = 0;
            this.checkBoxDryAntiBac.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.checkBoxDryAntiBac.CheckMarkColor = System.Drawing.SystemColors.ActiveCaption;
            this.checkBoxDryAntiBac.Location = new System.Drawing.Point(66, 85);
            this.checkBoxDryAntiBac.Name = "checkBoxDryAntiBac";
            this.checkBoxDryAntiBac.Size = new System.Drawing.Size(20, 20);
            this.checkBoxDryAntiBac.TabIndex = 19;
            this.checkBoxDryAntiBac.Text = "guna2CustomCheckBox1";
            this.checkBoxDryAntiBac.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.checkBoxDryAntiBac.UncheckedState.BorderRadius = 2;
            this.checkBoxDryAntiBac.UncheckedState.BorderThickness = 1;
            this.checkBoxDryAntiBac.UncheckedState.FillColor = System.Drawing.Color.White;
            this.checkBoxDryAntiBac.Click += new System.EventHandler(this.checkBoxDryAntiBac_Click);
            // 
            // guna2HtmlLabel14
            // 
            this.guna2HtmlLabel14.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel14.Font = new System.Drawing.Font("Segoe UI", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel14.ForeColor = System.Drawing.Color.Teal;
            this.guna2HtmlLabel14.Location = new System.Drawing.Point(198, 13);
            this.guna2HtmlLabel14.Name = "guna2HtmlLabel14";
            this.guna2HtmlLabel14.Size = new System.Drawing.Size(132, 32);
            this.guna2HtmlLabel14.TabIndex = 18;
            this.guna2HtmlLabel14.Text = "Dry Cleaning";
            // 
            // StatusPanel
            // 
            this.StatusPanel.Controls.Add(this.guna2Panel2);
            this.StatusPanel.Controls.Add(this.TransactionStatusDataGridView);
            this.StatusPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.StatusPanel.Location = new System.Drawing.Point(146, 129);
            this.StatusPanel.Name = "StatusPanel";
            this.StatusPanel.Size = new System.Drawing.Size(875, 514);
            this.StatusPanel.TabIndex = 18;
            this.StatusPanel.Visible = false;
            // 
            // guna2Panel2
            // 
            this.guna2Panel2.Controls.Add(this.cancelTransaction);
            this.guna2Panel2.Controls.Add(this.refresh);
            this.guna2Panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.guna2Panel2.Location = new System.Drawing.Point(0, 348);
            this.guna2Panel2.Name = "guna2Panel2";
            this.guna2Panel2.Size = new System.Drawing.Size(875, 166);
            this.guna2Panel2.TabIndex = 1;
            // 
            // cancelTransaction
            // 
            this.cancelTransaction.BorderRadius = 5;
            this.cancelTransaction.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.cancelTransaction.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.cancelTransaction.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.cancelTransaction.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.cancelTransaction.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.cancelTransaction.FillColor = System.Drawing.Color.Teal;
            this.cancelTransaction.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.cancelTransaction.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.cancelTransaction.ForeColor = System.Drawing.Color.White;
            this.cancelTransaction.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.cancelTransaction.Location = new System.Drawing.Point(487, 80);
            this.cancelTransaction.Name = "cancelTransaction";
            this.cancelTransaction.Size = new System.Drawing.Size(128, 29);
            this.cancelTransaction.TabIndex = 7;
            this.cancelTransaction.Text = "Cancel Drop-off";
            // 
            // refresh
            // 
            this.refresh.BorderRadius = 5;
            this.refresh.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.refresh.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.refresh.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.refresh.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.refresh.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.refresh.FillColor = System.Drawing.Color.Teal;
            this.refresh.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.refresh.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.refresh.ForeColor = System.Drawing.Color.White;
            this.refresh.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.refresh.Location = new System.Drawing.Point(220, 80);
            this.refresh.Name = "refresh";
            this.refresh.Size = new System.Drawing.Size(110, 29);
            this.refresh.TabIndex = 6;
            this.refresh.Text = "Refresh";
            this.refresh.Click += new System.EventHandler(this.refresh_Click);
            // 
            // TransactionStatusDataGridView
            // 
            this.TransactionStatusDataGridView.AllowUserToResizeRows = false;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(224)))), ((int)(((byte)(244)))));
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.TransactionStatusDataGridView.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle5;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(152)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.TransactionStatusDataGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.TransactionStatusDataGridView.ColumnHeadersHeight = 15;
            this.TransactionStatusDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.TransactionStatusDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.TrackNumber,
            this.IDNumber,
            this.Type,
            this.DateTimeSchedule,
            this.Status,
            this.TotalPrice});
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(234)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(119)))), ((int)(((byte)(186)))), ((int)(((byte)(231)))));
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.TransactionStatusDataGridView.DefaultCellStyle = dataGridViewCellStyle7;
            this.TransactionStatusDataGridView.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(220)))), ((int)(((byte)(242)))));
            this.TransactionStatusDataGridView.Location = new System.Drawing.Point(0, 0);
            this.TransactionStatusDataGridView.Name = "TransactionStatusDataGridView";
            this.TransactionStatusDataGridView.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.TransactionStatusDataGridView.RowHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.TransactionStatusDataGridView.RowHeadersVisible = false;
            this.TransactionStatusDataGridView.Size = new System.Drawing.Size(875, 514);
            this.TransactionStatusDataGridView.TabIndex = 0;
            this.TransactionStatusDataGridView.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.FeterRiver;
            this.TransactionStatusDataGridView.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(224)))), ((int)(((byte)(244)))));
            this.TransactionStatusDataGridView.ThemeStyle.AlternatingRowsStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TransactionStatusDataGridView.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.SystemColors.ControlText;
            this.TransactionStatusDataGridView.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.TransactionStatusDataGridView.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.TransactionStatusDataGridView.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.TransactionStatusDataGridView.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(220)))), ((int)(((byte)(242)))));
            this.TransactionStatusDataGridView.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(152)))), ((int)(((byte)(219)))));
            this.TransactionStatusDataGridView.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.TransactionStatusDataGridView.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TransactionStatusDataGridView.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.TransactionStatusDataGridView.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.TransactionStatusDataGridView.ThemeStyle.HeaderStyle.Height = 15;
            this.TransactionStatusDataGridView.ThemeStyle.ReadOnly = false;
            this.TransactionStatusDataGridView.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(234)))), ((int)(((byte)(247)))));
            this.TransactionStatusDataGridView.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.TransactionStatusDataGridView.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TransactionStatusDataGridView.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.TransactionStatusDataGridView.ThemeStyle.RowsStyle.Height = 22;
            this.TransactionStatusDataGridView.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(119)))), ((int)(((byte)(186)))), ((int)(((byte)(231)))));
            this.TransactionStatusDataGridView.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            // 
            // TrackNumber
            // 
            this.TrackNumber.DataPropertyName = "TrackNumber";
            this.TrackNumber.HeaderText = "Track Number";
            this.TrackNumber.Name = "TrackNumber";
            // 
            // IDNumber
            // 
            this.IDNumber.DataPropertyName = "IDNumber";
            this.IDNumber.HeaderText = "ID Number";
            this.IDNumber.Name = "IDNumber";
            this.IDNumber.ReadOnly = true;
            // 
            // Type
            // 
            this.Type.DataPropertyName = "Type";
            this.Type.HeaderText = "Type";
            this.Type.Name = "Type";
            // 
            // DateTimeSchedule
            // 
            this.DateTimeSchedule.DataPropertyName = "DateTimeScheduled";
            this.DateTimeSchedule.HeaderText = "DateTimeScheduled";
            this.DateTimeSchedule.Name = "DateTimeSchedule";
            // 
            // Status
            // 
            this.Status.DataPropertyName = "Status";
            this.Status.HeaderText = "Status";
            this.Status.Name = "Status";
            // 
            // TotalPrice
            // 
            this.TotalPrice.DataPropertyName = "TotalPrice";
            this.TotalPrice.HeaderText = "Total Price";
            this.TotalPrice.Name = "TotalPrice";
            // 
            // PanelInfo
            // 
            this.PanelInfo.BackColor = System.Drawing.Color.Transparent;
            this.PanelInfo.Controls.Add(this.lblGender);
            this.PanelInfo.Controls.Add(this.lblContact);
            this.PanelInfo.Controls.Add(this.lblID);
            this.PanelInfo.Controls.Add(this.label1);
            this.PanelInfo.CustomizableEdges.BottomLeft = false;
            this.PanelInfo.CustomizableEdges.TopLeft = false;
            this.PanelInfo.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.PanelInfo.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.PanelInfo.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.PanelInfo.Location = new System.Drawing.Point(146, 129);
            this.PanelInfo.Name = "PanelInfo";
            this.PanelInfo.Size = new System.Drawing.Size(242, 173);
            this.PanelInfo.TabIndex = 8;
            this.PanelInfo.Visible = false;
            // 
            // lblGender
            // 
            this.lblGender.AutoSize = true;
            this.lblGender.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGender.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblGender.Location = new System.Drawing.Point(22, 107);
            this.lblGender.Name = "lblGender";
            this.lblGender.Size = new System.Drawing.Size(45, 13);
            this.lblGender.TabIndex = 3;
            this.lblGender.Text = "Gender";
            // 
            // lblContact
            // 
            this.lblContact.AutoSize = true;
            this.lblContact.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblContact.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblContact.Location = new System.Drawing.Point(22, 83);
            this.lblContact.Name = "lblContact";
            this.lblContact.Size = new System.Drawing.Size(47, 13);
            this.lblContact.TabIndex = 2;
            this.lblContact.Text = "Contact";
            // 
            // lblID
            // 
            this.lblID.AutoSize = true;
            this.lblID.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblID.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblID.Location = new System.Drawing.Point(22, 56);
            this.lblID.Name = "lblID";
            this.lblID.Size = new System.Drawing.Size(61, 13);
            this.lblID.TabIndex = 1;
            this.lblID.Text = "ID number";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(12, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Profile Info";
            // 
            // UserForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1021, 643);
            this.Controls.Add(this.PanelInfo);
            this.Controls.Add(this.StatusPanel);
            this.Controls.Add(this.RequestPanel);
            this.Controls.Add(this.sidenavbar);
            this.Controls.Add(this.guna2GradientPanel2);
            this.Controls.Add(this.guna2GradientPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "UserForm";
            this.Text = "UserForm";
            this.Load += new System.EventHandler(this.UserForm_Load);
            this.guna2GradientPanel1.ResumeLayout(false);
            this.guna2GradientPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox1)).EndInit();
            this.guna2GradientPanel2.ResumeLayout(false);
            this.guna2Panel5.ResumeLayout(false);
            this.guna2Panel1.ResumeLayout(false);
            this.sidenavbar.ResumeLayout(false);
            this.guna2GradientPanel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbProfile)).EndInit();
            this.RequestPanel.ResumeLayout(false);
            this.RequestPanel.PerformLayout();
            this.guna2GradientPanel5.ResumeLayout(false);
            this.SpecialtyCleaningPanel.ResumeLayout(false);
            this.SpecialtyCleaningPanel.PerformLayout();
            this.guna2GradientPanel9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.numUpSpecialLoad)).EndInit();
            this.StandardPanel.ResumeLayout(false);
            this.StandardPanel.PerformLayout();
            this.guna2GradientPanel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.numUpLoad)).EndInit();
            this.DryCleaningPanel.ResumeLayout(false);
            this.DryCleaningPanel.PerformLayout();
            this.guna2GradientPanel8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.numUpDryLoad)).EndInit();
            this.StatusPanel.ResumeLayout(false);
            this.guna2Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.TransactionStatusDataGridView)).EndInit();
            this.PanelInfo.ResumeLayout(false);
            this.PanelInfo.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel1;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel2;
        private Guna.UI2.WinForms.Guna2GradientTileButton btnSignUp;
        private Guna.UI2.WinForms.Guna2GradientPanel sidenavbar;
        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel4;
        private Guna.UI2.WinForms.Guna2GradientButton btnDropOff;
        private Guna.UI2.WinForms.Guna2PictureBox pbProfile;
        private Guna.UI2.WinForms.Guna2GradientButton btnAboutUsPanel;
        private Guna.UI2.WinForms.Guna2GradientButton btnEditProfilePanel;
        private Guna.UI2.WinForms.Guna2GradientButton btnProfilename;
        private Guna.UI2.WinForms.Guna2GradientButton btnStatusPanel;
        private Guna.UI2.WinForms.Guna2CirclePictureBox guna2CirclePictureBox1;
        private Guna.UI2.WinForms.Guna2GradientPanel RequestPanel;
        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel5;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel5;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel6;
        private Guna.UI2.WinForms.Guna2ImageButton btnSpecial;
        private Guna.UI2.WinForms.Guna2ImageButton btnDryClean;
        private Guna.UI2.WinForms.Guna2ImageButton btnStandard;
        private Guna.UI2.WinForms.Guna2GradientButton btnStandardAddTransaction;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel8;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel7;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel6;
        private Guna.UI2.WinForms.Guna2GradientPanel StatusPanel;
        private Guna.UI2.WinForms.Guna2DataGridView TransactionStatusDataGridView;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel2;
        private Guna.UI2.WinForms.Guna2CustomGradientPanel StandardPanel;
        private Guna.UI2.WinForms.Guna2HtmlLabel oy;
        private Guna.UI2.WinForms.Guna2CustomCheckBox checkBoxFabSoft;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel5;
        private Guna.UI2.WinForms.Guna2CustomCheckBox checkBoxScent;
        private Guna.UI2.WinForms.Guna2HtmlLabel oi;
        private Guna.UI2.WinForms.Guna2CustomCheckBox checkBoxIron;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel3;
        private Guna.UI2.WinForms.Guna2CustomCheckBox checkBoxAntiBac;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel10;
        private Guna.UI2.WinForms.Guna2CustomCheckBox checkBoxGentWash;
        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel6;
        private System.Windows.Forms.RichTextBox txtStandardTotal;
        private Guna.UI2.WinForms.Guna2NumericUpDown numUpLoad;
        private Guna.UI2.WinForms.Guna2CustomGradientPanel DryCleaningPanel;
        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel8;
        private System.Windows.Forms.RichTextBox txtDryTotalPrice;
        private Guna.UI2.WinForms.Guna2GradientButton btnDryAddTransaction;
        private Guna.UI2.WinForms.Guna2NumericUpDown numUpDryLoad;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel4;
        private Guna.UI2.WinForms.Guna2CustomCheckBox checkBoxDelCare;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel9;
        private Guna.UI2.WinForms.Guna2CustomCheckBox checkBoxDryFabSoft;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel11;
        private Guna.UI2.WinForms.Guna2CustomCheckBox checkBoxDryMinorRepair;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel12;
        private Guna.UI2.WinForms.Guna2CustomCheckBox checkBoxDryPress;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel13;
        private Guna.UI2.WinForms.Guna2CustomCheckBox checkBoxDryAntiBac;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel14;
        private Guna.UI2.WinForms.Guna2CustomGradientPanel SpecialtyCleaningPanel;
        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel9;
        private System.Windows.Forms.RichTextBox txtSpecialtyTotalPrice;
        private Guna.UI2.WinForms.Guna2GradientButton btnSpecialtyAddTransaction;
        private Guna.UI2.WinForms.Guna2NumericUpDown numUpSpecialLoad;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel15;
        private Guna.UI2.WinForms.Guna2CustomCheckBox checkBoxSpecialStainRemove;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel16;
        private Guna.UI2.WinForms.Guna2CustomCheckBox checkBoxSpecialFabSoft;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel17;
        private Guna.UI2.WinForms.Guna2CustomCheckBox checkBoxSpecialHand;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel18;
        private Guna.UI2.WinForms.Guna2CustomCheckBox checkBoxSpecialEco;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel19;
        private Guna.UI2.WinForms.Guna2CustomCheckBox checkBoxSpecialAntiBac;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel20;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel2;
        private Guna.UI2.WinForms.Guna2GradientButton cancelTransaction;
        private Guna.UI2.WinForms.Guna2GradientButton refresh;
        private System.Windows.Forms.DataGridViewTextBoxColumn TrackNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn IDNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn Type;
        private System.Windows.Forms.DataGridViewTextBoxColumn DateTimeSchedule;
        private System.Windows.Forms.DataGridViewTextBoxColumn Status;
        private System.Windows.Forms.DataGridViewTextBoxColumn TotalPrice;
        private Guna.UI2.WinForms.Guna2GradientPanel PanelInfo;
        private System.Windows.Forms.Label lblGender;
        private System.Windows.Forms.Label lblContact;
        private System.Windows.Forms.Label lblID;
        private System.Windows.Forms.Label label1;
    }
}