﻿
using Appsdev.DBHelper;
using RenewWear_EcoFit.Connections;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RenewWear_EcoFit.Forms
{
    public partial class AdminForm : Form
    {
        public AdminForm()
        {
            InitializeComponent();

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void AdminForm_Load(object sender, EventArgs e)
        {

            PopulateDataGridView();
        }

        private void PopulateDataGridView()
        {
            string query = "SELECT UserID, FirstName, LastName, IDNumber, ContactNumber, Gender FROM UserDetails";
            DBHelper.FillDataGridView(query, AccountDataGrid);
        }

        //Gamiton later
        private void PopulateTransactionStatusDataGridView()
        {
            try
            {
                Connection.DB();

                string query = @"SELECT TransactionHistory.TrackNumber, UserDetails.IDNumber, TransactionHistory.Type, 
                                    TransactionHistory.DateTimeScheduled, TransactionHistory.Status, TransactionHistory.TotalPrice
                                    FROM UserDetails
                                    INNER JOIN TransactionHistory ON UserDetails.UserID = TransactionHistory.UserID";

                DataTable dataTable = new DataTable();
                OleDbDataAdapter dataAdapter = new OleDbDataAdapter(query, Connection.conn);
                dataAdapter.Fill(dataTable);
                TransactionStatusDataGridView.DataSource = dataTable;

                Connection.conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                string firstName = txtFirstname.Text;
                string lastName = txtLastname.Text;
                int userid = int.Parse(txtSearchID.Text);
                int idNumber = int.Parse(txtSchoolID.Text);
                int contactNumber = int.Parse(txtContact.Text);
                string gender = comboBoxGender.SelectedItem.ToString();
     
                string checkUserIDQuery = $"SELECT COUNT(*) FROM UserDetails WHERE UserID = {userid}";
                int existingRecordsCount = (int)DBHelper.ExecuteScalar(checkUserIDQuery);
                if (existingRecordsCount > 0)
                {
                    MessageBox.Show("A user with the same UserID already exists.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return; 
                }

                string insertQuery = $"INSERT INTO UserDetails (UserID, FirstName, LastName, IDNumber, ContactNumber, Gender) " +
                                     $"VALUES ({userid}, '{firstName}', '{lastName}', {idNumber}, {contactNumber}, '{gender}')";

                DBHelper.ModifyRecord(insertQuery);
                PopulateDataGridView();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error adding record: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                int userID = int.Parse(txtSearchID.Text);
                string firstName = txtFirstname.Text;
                string lastName = txtLastname.Text;
                int idNumber = int.Parse(txtSchoolID.Text);
                int contactNumber = int.Parse(txtContact.Text);
                string gender = comboBoxGender.SelectedItem.ToString();

                string updateQuery = $"UPDATE UserDetails SET FirstName = '{firstName}', LastName = '{lastName}', " +
                                     $"IDNumber = {idNumber}, ContactNumber = {contactNumber}, Gender = '{gender}' " +
                                     $"WHERE UserID = {userID}";

                DBHelper.ModifyRecord(updateQuery);
                PopulateDataGridView(); 
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating record: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                int userID = int.Parse(txtSearchID.Text);


                string deleteUserLoginQuery = $"DELETE FROM UserLogin WHERE UserID = {userID}";
                DBHelper.ModifyRecord(deleteUserLoginQuery);


                string deleteUserDetailsQuery = $"DELETE FROM UserDetails WHERE UserID = {userID}";
                DBHelper.ModifyRecord(deleteUserDetailsQuery);


                PopulateDataGridView();


                txtFirstname.Clear();
                txtLastname.Clear();
                txtSchoolID.Clear();
                txtContact.Clear();
                comboBoxGender.SelectedItem = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error deleting record: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void txtSearchID_TextChanged(object sender, EventArgs e)
        {
            if (int.TryParse(txtSearchID.Text, out int userID) && userID > 0)
            {
                try
                {
                    string query = $"SELECT * FROM UserDetails WHERE UserID = {userID}";
                    DataTable dataTable = new DataTable();
                    OleDbDataAdapter dataAdapter = new OleDbDataAdapter(query, Connection.conn);
                    dataAdapter.Fill(dataTable);
                    //DBHelper.FillDataGridView(query, AccountDataGrid);

                    if (dataTable.Rows.Count > 0)
                    {
                        DataRow row = dataTable.Rows[0]; 
                        txtFirstname.Text = row["FirstName"].ToString();
                        txtLastname.Text = row["LastName"].ToString();
                        txtSchoolID.Text = row["IDNumber"].ToString();
                        txtContact.Text = row["ContactNumber"].ToString();
                        comboBoxGender.SelectedItem = row["Gender"].ToString();
                    }
                    else
                    {
                        
                        txtFirstname.Clear();
                        txtLastname.Clear();
                        txtSchoolID.Clear();
                        txtContact.Clear();
                        comboBoxGender.SelectedItem = null;
    
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error searching record: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
              
                txtFirstname.Clear();
                txtLastname.Clear();
                txtSchoolID.Clear();
                txtContact.Clear();
                comboBoxGender.SelectedItem = null;
            }
        }





        private void btnManageSchedulePanel_Click(object sender, EventArgs e)
        {
            btnManageSchedulePanel.FillColor = Color.FromArgb(0, 192, 192); 
            btnManageAccountPanel.FillColor = Color.Teal;
            btnGenerateReportPanel.FillColor = Color.Teal; 
            btnAboutUsPanel.FillColor = Color.Teal;

            btnManageSchedulePanel.FillColor2 = Color.Teal;
            btnManageAccountPanel.FillColor2 = Color.FromArgb(0, 64, 64);
            btnGenerateReportPanel.FillColor2 = Color.FromArgb(0, 64, 64);
            btnAboutUsPanel.FillColor2 = Color.FromArgb(0, 64, 64);
        }

        private void btnManageAccountPanel_Click(object sender, EventArgs e)
        {
            btnManageSchedulePanel.FillColor = Color.Teal;
            btnManageAccountPanel.FillColor = Color.FromArgb(0, 192, 192);
            btnGenerateReportPanel.FillColor = Color.Teal;
            btnAboutUsPanel.FillColor = Color.Teal;

            btnManageSchedulePanel.FillColor2 = Color.FromArgb(0, 64, 64);
            btnManageAccountPanel.FillColor2 = Color.Teal;
            btnGenerateReportPanel.FillColor2 = Color.FromArgb(0, 64, 64);
            btnAboutUsPanel.FillColor2 = Color.FromArgb(0, 64, 64);

        }

        private void btnGenerateReportPanel_Click(object sender, EventArgs e)
        {
            btnManageSchedulePanel.FillColor = Color.Teal;
            btnManageAccountPanel.FillColor = Color.Teal;
            btnGenerateReportPanel.FillColor = Color.FromArgb(0, 192, 192);
            btnAboutUsPanel.FillColor = Color.Teal;

            btnManageSchedulePanel.FillColor2 = Color.FromArgb(0, 64, 64);
            btnManageAccountPanel.FillColor2 = Color.FromArgb(0, 64, 64);
            btnGenerateReportPanel.FillColor2 = Color.Teal;
            btnAboutUsPanel.FillColor2 = Color.FromArgb(0, 64, 64);
        }
        private void btnAboutUsPanel_Click(object sender, EventArgs e)
        {
            btnManageSchedulePanel.FillColor = Color.Teal;
            btnManageAccountPanel.FillColor = Color.Teal;
            btnGenerateReportPanel.FillColor = Color.Teal;
            btnAboutUsPanel.FillColor = Color.FromArgb(0, 192, 192);

            btnManageSchedulePanel.FillColor2 = Color.FromArgb(0, 64, 64);
            btnManageAccountPanel.FillColor2 = Color.FromArgb(0, 64, 64);
            btnGenerateReportPanel.FillColor2 = Color.FromArgb(0, 64, 64);
            btnAboutUsPanel.FillColor2 = Color.Teal;
        }

        private void btnSignUp_Click(object sender, EventArgs e)
        {
            CrystalReport report = new CrystalReport();
            report.Show();
        }
    }
}
