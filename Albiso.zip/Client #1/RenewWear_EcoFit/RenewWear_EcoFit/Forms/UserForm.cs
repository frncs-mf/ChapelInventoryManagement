﻿using RenewWear_EcoFit.Connections;
using RenewWear_EcoFit.UserDataAccess;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace RenewWear_EcoFit.Forms
{
    public partial class UserForm : Form
    {
        private int userID;
        private string firstname;
        private string lastname;
        private int idnumber;
        private int contact;
        private string gender;
        public decimal standardtotalprice = 100.00m;
        public decimal drytotalprice = 200.00m;
        public decimal specialtotalprice = 250.00m;
        bool isVisible = false;
        public UserForm(int userID)
        {
            InitializeComponent();
            LoadUserDetails(userID);
            this.userID = userID;
            
        }

        private void UserForm_Load(object sender, EventArgs e)
        {

            PopulateTransactionStatusDataGridView();
        }
        private void LoadUserDetails(int userID)
        {
            
            DataAccess.RetrieveUserDetails(userID, out firstname, out lastname, out idnumber, out contact, out gender);

            
            if (!string.IsNullOrEmpty(firstname) && !string.IsNullOrEmpty(lastname))
            {
                btnProfilename.Text = firstname + " " + gender;
                lblID.Text = "ID number: " + idnumber;
                lblContact.Text = "Contact: " + contact;
                lblGender.Text = "Gender: " + gender;
            }
            else
            {
                MessageBox.Show("User details not found!");
            }
        }


        private void PopulateTransactionStatusDataGridView()
        {
            Connection.DB();

            string query = "SELECT TH.TrackNumber, UD.IDNumber, TH.Type, TH.DateTimeScheduled, TH.Status, TH.TotalPrice " +
                           "FROM TransactionHistory AS TH " +
                           "INNER JOIN UserDetails AS UD ON TH.UserID = UD.UserID " +
                           "WHERE TH.UserID = @UserID";

            using (OleDbCommand command = new OleDbCommand(query, Connections.Connection.conn))
            {
                command.Parameters.AddWithValue("@UserID", userID);

                using (OleDbDataReader reader = command.ExecuteReader())
                {
                    TransactionStatusDataGridView.Rows.Clear();

                    while (reader.Read())
                    {
                        int trackNumber = reader.GetInt32(0);
                        int idNumber = reader.GetInt32(1);
                        string type = reader.GetString(2);
                        DateTime dateTimeScheduled = reader.GetDateTime(3);
                        string status = reader.GetString(4);
                        decimal totalPrice = reader.GetDecimal(5);

                        TransactionStatusDataGridView.Rows.Add(trackNumber, idNumber, type, dateTimeScheduled, status, totalPrice);
                    }
                }
            }
        }

        private void btnDropOff_Click(object sender, EventArgs e)
        {
            RequestPanel.Visible = true;
            StatusPanel.Visible = false;


            btnDropOff.FillColor = Color.FromArgb(0, 192, 192);
            btnStatusPanel.FillColor = Color.Teal;
            btnEditProfilePanel.FillColor = Color.Teal;
            btnAboutUsPanel.FillColor = Color.Teal;

            btnDropOff.FillColor2 = Color.Teal;
            btnStatusPanel.FillColor2 = Color.FromArgb(0, 64, 64);
            btnEditProfilePanel.FillColor2 = Color.FromArgb(0, 64, 64);
            btnAboutUsPanel.FillColor2 = Color.FromArgb(0, 64, 64);
        }

        private void btnStatusPanel_Click(object sender, EventArgs e)
        {
            RequestPanel.Visible = false;
            StatusPanel.Visible = true;

            btnDropOff.FillColor = Color.Teal;
            btnStatusPanel.FillColor = Color.FromArgb(0, 192, 192);
            btnEditProfilePanel.FillColor = Color.Teal;
            btnAboutUsPanel.FillColor = Color.Teal;

            btnDropOff.FillColor2 = Color.FromArgb(0, 64, 64);
            btnStatusPanel.FillColor2 = Color.Teal;
            btnEditProfilePanel.FillColor2 = Color.FromArgb(0, 64, 64);
            btnAboutUsPanel.FillColor2 = Color.FromArgb(0, 64, 64);

        }

        private void btnEditProfilePanel_Click(object sender, EventArgs e)
        {
            btnDropOff.FillColor = Color.Teal;
            btnStatusPanel.FillColor = Color.Teal;
            btnEditProfilePanel.FillColor = Color.FromArgb(0, 192, 192);
            btnAboutUsPanel.FillColor = Color.Teal;

            btnDropOff.FillColor2 = Color.FromArgb(0, 64, 64);
            btnStatusPanel.FillColor2 = Color.FromArgb(0, 64, 64);
            btnEditProfilePanel.FillColor2 = Color.Teal;
            btnAboutUsPanel.FillColor2 = Color.FromArgb(0, 64, 64);
        }

        private void btnAboutUsPanel_Click(object sender, EventArgs e)
        {
            btnDropOff.FillColor = Color.Teal;
            btnStatusPanel.FillColor = Color.Teal;
            btnEditProfilePanel.FillColor = Color.Teal;
            btnAboutUsPanel.FillColor = Color.FromArgb(0, 192, 192);

            btnDropOff.FillColor2 = Color.FromArgb(0, 64, 64);
            btnStatusPanel.FillColor2 = Color.FromArgb(0, 64, 64);
            btnEditProfilePanel.FillColor2 = Color.FromArgb(0, 64, 64);
            btnAboutUsPanel.FillColor2 = Color.Teal;
        }

        private void btnStandard_Click(object sender, EventArgs e)
        {
            StandardPanel.Visible = true;
            DryCleaningPanel.Visible = false;
            SpecialtyCleaningPanel.Visible = false;
        }

        private void btnDryClean_Click(object sender, EventArgs e)
        {
            StandardPanel.Visible = false;
            DryCleaningPanel.Visible = true;
            SpecialtyCleaningPanel.Visible = false;
        }

        private void btnSpecial_Click(object sender, EventArgs e)
        {
            StandardPanel.Visible = false;
            DryCleaningPanel.Visible = false;
            SpecialtyCleaningPanel.Visible = true;
        }

        private void btnStandardAddTransaction_Click(object sender, EventArgs e)
        {


            Random random = new Random();
            DateTime dateTimeSchedule = DateTime.Now;
            int trackNumber = random.Next(100000, 999999);
            string type = "Standard Wash";
            string status = "Pending";

            bool success = DataAccess.AddTransaction(userID, trackNumber, type, dateTimeSchedule, status, standardtotalprice);

            if (success)
            {
                MessageBox.Show("Transaction added successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Failed to add transaction.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDryAddTransaction_Click(object sender, EventArgs e)
        {

            Random random = new Random();
            DateTime dateTimeSchedule = DateTime.Now;
            int trackNumber = random.Next(100000, 999999);
            string type = "Dry Cleaning";
            string status = "Pending";

            bool success = DataAccess.AddTransaction(userID, trackNumber, type, dateTimeSchedule, status, drytotalprice);

            if (success)
            {
                MessageBox.Show("Transaction added successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Failed to add transaction.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSpecialtyAddTransaction_Click(object sender, EventArgs e)
        {
            Random random = new Random();
            DateTime dateTimeSchedule = DateTime.Now;
            int trackNumber = random.Next(100000, 999999);
            string type = "Specialty Cleaning";
            string status = "Pending";

            bool success = DataAccess.AddTransaction(userID, trackNumber, type, dateTimeSchedule, status, specialtotalprice);

            if (success)
            {
                MessageBox.Show("Transaction added successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Failed to add transaction.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void refresh_Click(object sender, EventArgs e)
        {
            PopulateTransactionStatusDataGridView();
        }

        private void checkBoxSpecialAntiBac_Click(object sender, EventArgs e)
        {
            if (checkBoxSpecialAntiBac.Checked)
            {
                specialtotalprice += 30.00m;
            }
            else
            {
                specialtotalprice -= 30.00m;
            }
            txtSpecialtyTotalPrice.Text = "Total Price: ₱" + specialtotalprice.ToString("C");
        }

        private void checkBoxSpecialEco_Click(object sender, EventArgs e)
        {
            if (checkBoxSpecialEco.Checked)
            {
                specialtotalprice += 40.00m;
            }
            else
            {
                specialtotalprice -= 40.00m;
            }
            txtSpecialtyTotalPrice.Text = "Total Price: ₱" + specialtotalprice.ToString("C");
        }

        private void checkBoxSpecialHand_Click(object sender, EventArgs e)
        {
            if (checkBoxSpecialHand.Checked)
            {
                specialtotalprice += 70.00m;
            }
            else
            {
                specialtotalprice -= 70.00m;
            }
            txtSpecialtyTotalPrice.Text = "Total Price: ₱" + specialtotalprice.ToString("C");
        }

        private void checkBoxSpecialFabSoft_Click(object sender, EventArgs e)
        {
            if (checkBoxSpecialFabSoft.Checked)
            {
                specialtotalprice += 25.00m;
            }
            else
            {
                specialtotalprice -= 25.00m;
            }
            txtSpecialtyTotalPrice.Text = "Total Price: ₱" + specialtotalprice.ToString("C");
        }

        private void checkBoxSpecialStainRemove_Click(object sender, EventArgs e)
        {
            if (checkBoxSpecialStainRemove.Checked)
            {
                specialtotalprice += 60.00m;
            }
            else
            {
                specialtotalprice -= 60.00m;
            }
            txtSpecialtyTotalPrice.Text = "Total Price: ₱" + specialtotalprice.ToString("C");
        }

        private void checkBoxAntiBac_Click(object sender, EventArgs e)
        {
            if (checkBoxAntiBac.Checked)
            {
                standardtotalprice += 15.00m;
            }
            else
            {
                standardtotalprice -= 15.00m;
            }
            txtStandardTotal.Text = "Total Price: ₱" + standardtotalprice.ToString("C");
        }

        private void checkBoxIron_Click(object sender, EventArgs e)
        {
            if (checkBoxIron.Checked)
            {
                standardtotalprice += 30.00m;
            }
            else
            {
                standardtotalprice -= 30.00m;
            }
            txtStandardTotal.Text = "Total Price: ₱" + standardtotalprice.ToString("C");
        }

        private void checkBoxScent_Click(object sender, EventArgs e)
        {
            if (checkBoxScent.Checked)
            {
                standardtotalprice += 20.00m;
            }
            else
            {
                standardtotalprice -= 20.00m;
            }
            txtStandardTotal.Text = "Total Price: ₱" + standardtotalprice.ToString("C");
        }

        private void checkBoxFabSoft_Click(object sender, EventArgs e)
        {
            if (checkBoxFabSoft.Checked)
            {
                standardtotalprice += 10.00m;
            }
            else
            {
                standardtotalprice -= 10.00m;
            }
            txtStandardTotal.Text = "Total Price: ₱" + standardtotalprice.ToString("C");
        }

        private void checkBoxGentWash_Click(object sender, EventArgs e)
        {
            if (checkBoxGentWash.Checked)
            {
                standardtotalprice += 20.00m;
            }
            else
            {
                standardtotalprice -= 20.00m;
            }
            txtStandardTotal.Text = "Total Price: ₱" + standardtotalprice.ToString("C");
        }

        private void checkBoxDryAntiBac_Click(object sender, EventArgs e)
        {
            if (checkBoxDryAntiBac.Checked)
            {
                drytotalprice += 25.00m;
            }
            else
            {
                drytotalprice -= 25.00m;
            }
            txtDryTotalPrice.Text = "Total Price: ₱" + drytotalprice.ToString("C");
        }

        private void checkBoxDryPress_Click(object sender, EventArgs e)
        {
            if (checkBoxDryPress.Checked)
            {
                drytotalprice += 30.00m;
            }
            else
            {
                drytotalprice -= 30.00m;
            }
            txtDryTotalPrice.Text = "Total Price: ₱" + drytotalprice.ToString("C");
        }

        private void checkBoxDryMinorRepair_Click(object sender, EventArgs e)
        {
            if (checkBoxDryMinorRepair.Checked)
            {
                drytotalprice += 40.00m;
            }
            else
            {
                drytotalprice -= 40.00m;
            }
            txtDryTotalPrice.Text = "Total Price: ₱" + drytotalprice.ToString("C");
        }

        private void checkBoxDryFabSoft_Click(object sender, EventArgs e)
        {
            if (checkBoxDryFabSoft.Checked)
            {
                drytotalprice += 20.00m;
            }
            else
            {
                drytotalprice -= 20.00m;
            }
            txtDryTotalPrice.Text = "Total Price: ₱" + drytotalprice.ToString("C");
        }

        private void checkBoxDelCare_Click(object sender, EventArgs e)
        {
            if (checkBoxDelCare.Checked)
            {
                drytotalprice += 50.00m;
            }
            else
            {
                drytotalprice -= 50.00m;
            }
            txtDryTotalPrice.Text = "Total Price: ₱" + drytotalprice.ToString("C");
        }

        private void numUpSpecialLoad_ValueChanged(object sender, EventArgs e)
        {

            decimal totalPrice = 250.00m;
            if (checkBoxSpecialAntiBac.Checked)
                totalPrice += 30.00m;

            if (checkBoxSpecialEco.Checked)
                totalPrice += 40.00m;

            if (checkBoxSpecialHand.Checked)
                totalPrice += 70.00m;

            if (checkBoxSpecialFabSoft.Checked)
                totalPrice += 25.00m;

            if (checkBoxSpecialStainRemove.Checked)
                totalPrice += 60.00m;

            totalPrice *= (decimal)numUpSpecialLoad.Value;

            txtSpecialtyTotalPrice.Text = "Total Price: ₱" + totalPrice.ToString("C");
        }

        private void numUpLoad_ValueChanged(object sender, EventArgs e)
        {
            decimal totalPrice = 100.00m;
            if (checkBoxAntiBac.Checked)
                totalPrice += 15.00m;

            if (checkBoxIron.Checked)
                totalPrice += 30.00m;

            if (checkBoxScent.Checked)
                totalPrice += 20.00m;

            if (checkBoxFabSoft.Checked)
                totalPrice += 10.00m;

            if (checkBoxGentWash.Checked)
                totalPrice += 20.00m;

            totalPrice *= (decimal)numUpLoad.Value;

            txtStandardTotal.Text = "Total Price: ₱" + totalPrice.ToString("C");
        }

        private void numUpDryLoad_ValueChanged(object sender, EventArgs e)
        {
            decimal totalPrice = 200.00m;
            if (checkBoxDryAntiBac.Checked)
                totalPrice += 25.00m;

            if (checkBoxDryPress.Checked)
                totalPrice += 30.00m;

            if (checkBoxDryMinorRepair.Checked)
                totalPrice += 40.00m;

            if (checkBoxDryFabSoft.Checked)
                totalPrice += 20.00m;

            if (checkBoxDelCare.Checked)
                totalPrice += 50.00m;

            totalPrice *= (decimal)numUpDryLoad.Value;

            txtDryTotalPrice.Text = "Total Price: ₱" + totalPrice.ToString("C");
        }

        private void btnProfilename_Click(object sender, EventArgs e)
        {
            if (!isVisible)
            {
                PanelInfo.Visible = true;
            }
            else
            {
                PanelInfo.Visible = false;
            }
            isVisible = !isVisible;
        }


    }
}
