﻿using RenewWear_EcoFit.Connections;
using System;
using System.Data;
using System.Data.OleDb;

namespace RenewWear_EcoFit.UserDataAccess
{
    internal static class DataAccess
    {
        internal static bool RegisterUser(string firstName, string lastName, int IDnumber, int contact, string password, string gender)
        {
            try
            {
                Connection.DB();
                using (OleDbTransaction transaction = Connection.conn.BeginTransaction())
                {
                    string checkIDnumberQuery = "SELECT COUNT(*) FROM UserLogin WHERE Username = @IDnumber";
                    using (OleDbCommand command = new OleDbCommand(checkIDnumberQuery, Connection.conn, transaction))
                    {
                        command.Parameters.AddWithValue("@IDnumber", IDnumber);

                        int idCount = (int)command.ExecuteScalar();
                        if (idCount > 0)
                        {
                            return false; 
                        }
                    }

                    string insertUserDetailsQuery = @"INSERT INTO [UserDetails] ([FirstName], [LastName], [IDNumber], [ContactNumber], [Gender]) 
                                              VALUES (@FirstName, @LastName, @IDNumber, @ContactNumber, @Gender)";
                    using (OleDbCommand command = new OleDbCommand(insertUserDetailsQuery, Connection.conn, transaction))
                    {
                        command.Parameters.AddWithValue("@FirstName", firstName);
                        command.Parameters.AddWithValue("@LastName", lastName);
                        command.Parameters.AddWithValue("@IDNumber", IDnumber);
                        command.Parameters.AddWithValue("@ContactNumber", contact);
                        command.Parameters.AddWithValue("@Gender", gender);
                        command.ExecuteNonQuery();
                    }

                    string getUserIdQuery = "SELECT UserID FROM UserDetails WHERE IDNumber = @IDNumber";
                    int userId;
                    using (OleDbCommand getIdCmd = new OleDbCommand(getUserIdQuery, Connection.conn, transaction))
                    {
                        getIdCmd.Parameters.AddWithValue("@IDNumber", IDnumber);
                        object result = getIdCmd.ExecuteScalar();
                        if (result != null && result != DBNull.Value)
                        {
                            userId = Convert.ToInt32(result);
                        }
                        else
                        {
                            throw new Exception("Failed to retrieve UserID for the registered user.");
                        }
                    }

                    string insertUserLoginQuery = @"INSERT INTO [UserLogin] ([UserID], [Username], [Password], [isActive]) 
                                            VALUES (@UserID, @Username, @Password, @IsActive)";
                    using (OleDbCommand command = new OleDbCommand(insertUserLoginQuery, Connection.conn, transaction))
                    {
                        command.Parameters.AddWithValue("@UserID", userId);
                        command.Parameters.AddWithValue("@Username", IDnumber.ToString());
                        command.Parameters.AddWithValue("@Password", password);
                        command.Parameters.AddWithValue("@IsActive", true);
                        command.ExecuteNonQuery();
                    }

                    transaction.Commit();
                    return true; 
                }
            }
            catch (Exception ex)
            {
                throw ex; 
            }
            finally
            {
                if (Connections.Connection.conn.State == ConnectionState.Open)
                {
                    Connections.Connection.conn.Close();
                }
            }
        }

        internal static bool AuthenticateUser(string username, string password)
        {
            try
            {
                Connections.Connection.DB();

                string query = "SELECT COUNT(*) FROM UserLogin WHERE Username = @Username AND Password = @Password";
                using (OleDbCommand command = new OleDbCommand(query, Connections.Connection.conn))
                {
                    command.Parameters.AddWithValue("@Username", username);
                    command.Parameters.AddWithValue("@Password", password);

                    int count = (int)command.ExecuteScalar();
                    return count > 0;
                }
            }
            catch (Exception ex)
            {

                throw ex;


            }
            finally
            {

                if (Connections.Connection.conn.State == ConnectionState.Open)
                {
                    Connections.Connection.conn.Close();
                }
            }
        }

        internal static int RetrieveUserID(string username)
        {
            try
            {
                Connections.Connection.DB();

                string query = "SELECT UserID FROM UserLogin WHERE Username = @Username";
                using (OleDbCommand command = new OleDbCommand(query, Connections.Connection.conn))
                {
                    command.Parameters.AddWithValue("@Username", username);

                    object result = command.ExecuteScalar();
                    if (result != null && result != DBNull.Value)
                    {
                        return Convert.ToInt32(result);
                    }
                    else
                    {
                        throw new Exception("Failed to retrieve UserID for the authenticated user.");
                    }
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
            finally
            {
                if (Connections.Connection.conn.State == ConnectionState.Open)
                {
                    Connections.Connection.conn.Close();
                }
            }
        }

        public static void RetrieveUserDetails(int userID, out string firstName, out string lastName, out int idNumber, out int contactNumber, out string gender)
        {
            firstName = "";
            lastName = "";
            idNumber = 0;
            contactNumber = 0;
            gender = "";

            try
            {
                Connections.Connection.DB();

                string query = "SELECT FirstName, LastName, IDNumber, ContactNumber, Gender FROM UserDetails WHERE UserID = @UserID";

                using (OleDbCommand command = new OleDbCommand(query, Connections.Connection.conn))
                {
                    command.Parameters.AddWithValue("@UserID", userID);

                    using (OleDbDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            firstName = reader.GetString(0);
                            lastName = reader.GetString(1);
                            idNumber = reader.GetInt32(2);
                            contactNumber = reader.GetInt32(3);
                            gender = reader.GetString(4);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error retrieving user details: " + ex.Message);
            }
            finally
            {
                if (Connections.Connection.conn.State == ConnectionState.Open)
                {
                    Connections.Connection.conn.Close();
                }
            }
        }

        internal static int RetrieveTrackNumber()
        {
            try
            {
                Connection.DB();
                string query = @"SELECT MIN(TransactionID) AS MinTransactionID
                         FROM TransactionHistory";

                using (OleDbCommand command = new OleDbCommand(query, Connection.conn))
                {
                    object result = command.ExecuteScalar();

                    if (result != null && result != DBNull.Value)
                    {
                        return Convert.ToInt32(result);
                    }
                    else
                    {

                        return -1;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error in RetrieveTrackNumber: " + ex.Message);
                throw ex;
            }
            finally
            {
                if (Connection.conn.State == ConnectionState.Open)
                {
                    Connection.conn.Close();
                }
            }
        }

        internal static bool AddTransaction(int userID, int trackNumber, string type, DateTime dateTimeSchedule, string status, decimal totalPrice)
        {
            try
            {
                Connection.DB();
                using (OleDbTransaction transaction = Connection.conn.BeginTransaction())
                {
                    string insertTransactionQuery = @"INSERT INTO [TransactionHistory] ([UserID], [TrackNumber], [Type], [DateTimeScheduled], [Status], [TotalPrice]) 
                                             VALUES (@UserID, @TrackNumber, @Type, @DateTimeScheduled, @Status, @TotalPrice)";
                    using (OleDbCommand command = new OleDbCommand(insertTransactionQuery, Connection.conn, transaction))
                    {
                        command.Parameters.AddWithValue("@UserID", userID);
                        command.Parameters.AddWithValue("@TrackNumber", trackNumber);
                        command.Parameters.AddWithValue("@Type", type);

                        command.Parameters.AddWithValue("@DateTimeScheduled", dateTimeSchedule.ToString("yyyy-MM-dd HH:mm:ss"));

                        command.Parameters.AddWithValue("@Status", status);
                        command.Parameters.AddWithValue("@TotalPrice", totalPrice);
                        command.ExecuteNonQuery();
                    }

                    transaction.Commit();
                    return true; 
                }
            }
            catch (Exception ex)
            {
                throw ex; 
            }
            finally
            {
                if (Connections.Connection.conn.State == ConnectionState.Open)
                {
                    Connections.Connection.conn.Close();
                }
            }
        }
    }

   
}
