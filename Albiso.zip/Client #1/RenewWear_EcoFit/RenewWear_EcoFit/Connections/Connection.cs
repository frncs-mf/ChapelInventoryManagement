﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.OleDb;
using System.Windows.Forms;

namespace RenewWear_EcoFit.Connections
{
    internal class Connection
    {
        public static OleDbConnection conn;
        private static string dbConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source='" + Application.StartupPath + "/RenewWearEcoFit.accdb'";
        

        public static void DB()
        {
            try
            {
                conn = new OleDbConnection(dbConnectionString);
                conn.Open();
                //MessageBox.Show("Database connection successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information); //Debug 5//11/2024

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error connecting to the database: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }
    }
}

