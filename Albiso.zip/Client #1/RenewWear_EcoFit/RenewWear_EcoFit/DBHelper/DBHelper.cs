﻿using System;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Data;
using RenewWear_EcoFit.Connections;

namespace Appsdev.DBHelper
{
    class DBHelper
    {
        public static void FillDataGridView(string query, DataGridView dataGridView)
        {
            try
            {
                Connection.DB(); 
                DataTable dataTable = new DataTable();
                OleDbDataAdapter dataAdapter = new OleDbDataAdapter(query, Connection.conn);
                dataAdapter.Fill(dataTable);
                dataGridView.DataSource = dataTable;
                Connection.conn.Close();
            }
            catch (Exception ex)
            {
                Connection.conn.Close();
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public static void ModifyRecord(string query)
        {
            try
            {
                Connection.DB(); 
                OleDbCommand command = new OleDbCommand(query, Connection.conn);
                command.ExecuteNonQuery();
                Connection.conn.Close();
            }
            catch (Exception ex)
            {
                Connection.conn.Close();
                MessageBox.Show("Error modifying record: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public static object ExecuteScalar(string query)
        {
            try
            {
                Connection.DB(); 
                OleDbCommand command = new OleDbCommand(query, Connection.conn);
                object result = command.ExecuteScalar();
                Connection.conn.Close();
                return result;
            }
            catch (Exception ex)
            {
                Connection.conn.Close();
                throw new Exception("Error executing query: " + ex.Message);
            }
        }
    }
}
